package com.mn.videoplayer

import android.app.Application
import com.yausername.youtubedl_android.YoutubeDL

class MnApp : Application() {
    override fun onCreate() {
        super.onCreate()
        YtDlp.appCtx = applicationContext
        // Prepare the yt-dlp engine in the background (first start takes a few seconds)
        Thread {
            try {
                YoutubeDL.getInstance().init(this)
                YtDlp.ready = true
            } catch (e: Throwable) {
                YtDlp.initError = e.message
            }
        }.start()
    }
}
