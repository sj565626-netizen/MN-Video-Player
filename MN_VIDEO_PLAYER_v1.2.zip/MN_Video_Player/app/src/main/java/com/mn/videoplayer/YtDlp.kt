package com.mn.videoplayer

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest

/** Gets the real, playable video address from any supported website link using yt-dlp. */
object YtDlp {
    @Volatile var ready = false
    @Volatile var initError: String? = null
    @Volatile private var updated = false

    class Found(val url: String, val title: String?, val headers: Map<String, String>, val mime: String?)

    private fun waitReady(): Boolean {
        var i = 0
        while (!ready && initError == null && i < 100) { // up to ~10 s
            Thread.sleep(100); i++
        }
        return ready
    }

    /** Returns the playable address, or throws an exception whose message explains the problem. */
    fun extract(link: String): Found {
        if (!waitReady()) throw IllegalStateException("The link engine could not start. ${initError ?: ""}".trim())
        return try {
            run(link)
        } catch (e: Exception) {
            // Sites change often. Update yt-dlp once and try again.
            if (!updated && !isUserProblem(e.message)) {
                updated = true
                try { YoutubeDL.getInstance().updateYoutubeDL(appCtx!!) } catch (_: Throwable) {}
                run(link)
            } else throw e
        }
    }

    var appCtx: Context? = null

    private fun isUserProblem(m: String?): Boolean {
        val s = (m ?: "").lowercase()
        return s.contains("login") || s.contains("private") || s.contains("sign in") ||
                s.contains("drm") || s.contains("not available") || s.contains("unsupported url") ||
                s.contains("unable to resolve") || s.contains("geo")
    }

    private fun run(link: String): Found {
        val req = YoutubeDLRequest(link)
        // single file with video+audio together, MP4 first; HLS streams are fine too
        req.addOption("-f", "best[ext=mp4]/best")
        req.addOption("--no-playlist")
        req.addOption("--no-warnings")
        req.addOption("--socket-timeout", "15")
        val info = YoutubeDL.getInstance().getInfo(req)
        val url = info.url
        if (url.isNullOrBlank()) throw IllegalStateException("No playable video was found at this link.")
        val h = HashMap<String, String>()
        info.httpHeaders?.forEach { (k, v) -> if (k != null && v != null) h[k] = v }
        val mime = when {
            url.contains(".m3u8", true) -> androidx.media3.common.MimeTypes.APPLICATION_M3U8
            url.contains(".mpd", true) -> androidx.media3.common.MimeTypes.APPLICATION_MPD
            else -> null
        }
        return Found(url, info.title, h, mime)
    }

    fun friendly(m: String?): String {
        val s = (m ?: "").lowercase()
        return when {
            s.contains("drm") -> "This video is DRM-protected (Netflix, Prime, Disney+ ...). It can't be played here."
            s.contains("login") || s.contains("sign in") || s.contains("cookies") || s.contains("private") ->
                "This video is private or needs a login, so it can't be opened."
            s.contains("geo") || s.contains("country") -> "This video is blocked in your country."
            s.contains("unsupported url") -> "This website is not supported."
            s.contains("not available") || s.contains("removed") || s.contains("deleted") -> "This video is not available any more."
            s.contains("unable to resolve") || s.contains("network") || s.contains("timed out") ->
                "Can't reach this address. Check the link and your internet connection."
            else -> "Couldn't get a playable video from this link."
        }
    }
}
