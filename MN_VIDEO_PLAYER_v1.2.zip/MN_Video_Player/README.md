# MN Video Player

Native Android (Kotlin) video player built on Media3 ExoPlayer. English UI.

Build: upload this zip to a GitHub repo as `MN_VIDEO_PLAYER.zip` (or upload the extracted folder),
add `.github/workflows/build.yml`, run "Build MN Video Player APK" in the Actions tab, download the APK artifact.

## Version 1.1 – what changed
- Screen fit: all screens respect the status bar, camera cut-out and navigation bar (nothing hides under them).
- Settings: every option has an icon, a short explanation and a switch / value.
- All menus (video options, More, Subtitles) now show icons.
- New logo, adaptive + themed (monochrome) launcher icon, splash icon.
- Network streams: link is checked first (redirects, HLS/DASH detection, video found inside simple web pages),
  RTSP module added, browser-like user agent, plain-language error messages.
  Page links from YouTube / Facebook / Instagram etc. are not video files and are explained clearly.
- Private Vault: PIN protected, files stored in app-private storage, hidden from gallery, screenshots blocked.
- New: favorites, jump to time, shuffle, default playback speed, paste/clipboard stream links.

## Version 1.2 – network streams for every site
- yt-dlp engine (youtubedl-android) added: YouTube, Facebook, Instagram, TikTok, X/Twitter, Vimeo, Dailymotion, Twitch,
  Reddit and 1000+ other sites now open from the normal page link.
- Direct files, HLS, DASH, RTSP still work as before.
- Not possible: DRM videos (Netflix, Prime ...), private / login-only videos, geo-blocked videos.
- The engine updates itself once if a site stops working.

## Features
Video library (grid/list, folders, favorites, search, sort), network streams (HTTP/HTTPS/HLS/DASH/RTSP), history and
resume, gestures (brightness, volume, seek, double-tap seek, pinch zoom, long-press 2x), speed 0.25x-4x,
audio and subtitle track selection, external subtitles (SRT/VTT/ASS/TTML) with size and color, aspect modes,
orientation control, screen lock, A-B repeat, repeat modes, shuffle, sleep timer, equalizer and volume boost,
audio-only mode, background play, picture-in-picture, screenshot, video info, share, delete, private vault.
