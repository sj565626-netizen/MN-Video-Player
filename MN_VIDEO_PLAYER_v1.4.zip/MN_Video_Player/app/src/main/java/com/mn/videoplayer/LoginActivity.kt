package com.mn.videoplayer

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/** Log in to a website once, so private videos of your own account can be played. */
class LoginActivity : AppCompatActivity() {

    companion object {
        // A normal Chrome user agent (without the "wv" marker) so Google and others accept the login page
        private const val UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/124.0.0.0 Mobile Safari/537.36"

        fun start(ctx: Context, link: String?) {
            val i = Intent(ctx, LoginActivity::class.java)
            if (link != null) i.putExtra("link", link)
            ctx.startActivity(i)
        }
    }

    private lateinit var list: LinearLayout
    private lateinit var scroll: View
    private lateinit var hint: TextView
    private lateinit var webBox: View
    private lateinit var web: WebView
    private lateinit var prog: ProgressBar
    private lateinit var title: TextView
    private lateinit var done: TextView
    private var current: CookieStore.Site? = null
    private var fromLink = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.loginRoot)) { v, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            insets
        }
        list = findViewById(R.id.loginList)
        scroll = findViewById(R.id.loginScroll)
        hint = findViewById(R.id.loginHint)
        webBox = findViewById(R.id.loginWebBox)
        web = findViewById(R.id.loginWeb)
        prog = findViewById(R.id.loginProg)
        title = findViewById(R.id.loginTitle)
        done = findViewById(R.id.loginDone)

        findViewById<ImageButton>(R.id.loginBack).setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        done.setOnClickListener { finishLogin() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webBox.visibility == View.VISIBLE) {
                    if (web.canGoBack()) web.goBack() else if (fromLink) finish() else showList()
                } else finish()
            }
        })
        setupWeb()

        val link = intent.getStringExtra("link")
        if (link != null) {
            fromLink = true
            open(guessSite(link))
        } else {
            showList()
        }
    }

    override fun onDestroy() {
        try {
            web.stopLoading()
            web.destroy()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun guessSite(link: String): CookieStore.Site {
        val host = (Uri.parse(if (link.contains("://")) link else "https://$link").host ?: "").lowercase()
        fun has(vararg k: String) = k.any { host == it || host.endsWith(".$it") }
        return when {
            has("youtube.com", "youtu.be", "google.com") -> CookieStore.sites[0]
            has("facebook.com", "fb.watch", "fb.com") -> CookieStore.sites[1]
            has("instagram.com") -> CookieStore.sites[2]
            has("tiktok.com") -> CookieStore.sites[3]
            has("x.com", "twitter.com") -> CookieStore.sites[4]
            else -> CookieStore.customSite(host.ifEmpty { "example.com" })
        }
    }

    private fun setupWeb() {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.userAgentString = UA
        s.javaScriptCanOpenWindowsAutomatically = true
        s.setSupportMultipleWindows(false)
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(web, true)
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                prog.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                prog.visibility = View.GONE
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val sch = request?.url?.scheme ?: return false
                // Don't let the page jump into other apps (fb://, intent://): that would break the login
                return sch != "http" && sch != "https"
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                prog.progress = newProgress
                prog.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
            }
        }
    }

    // ------------------------------------------------------------------ site list

    private fun showList() {
        current = null
        try {
            web.stopLoading()
            web.loadUrl("about:blank")
        } catch (_: Exception) {
        }
        webBox.visibility = View.GONE
        done.visibility = View.GONE
        scroll.visibility = View.VISIBLE
        hint.visibility = View.VISIBLE
        title.text = "Log in to websites"
        buildList()
    }

    private fun buildList() {
        list.removeAllViews()
        for (s in CookieStore.sites) addSiteRow(s)
        for (h in CookieStore.customHosts(this)) addSiteRow(CookieStore.customSite(h))
        val other = Ui.row(this, R.drawable.ic_link, "Other website", "Enter the address of any website")
        other.setOnClickListener { askOther() }
        list.addView(other)
    }

    private fun addSiteRow(s: CookieStore.Site) {
        val on = CookieStore.isLoggedIn(this, s.id)
        val r = Ui.row(
            this, if (on) R.drawable.ic_unlock else R.drawable.ic_lock, s.name,
            if (on) "Logged in ✓  ·  tap to manage" else "Not logged in"
        )
        r.setOnClickListener { if (on) manage(s) else open(s) }
        list.addView(r)
    }

    private fun manage(s: CookieStore.Site) {
        Ui.menu(
            this, s.name, listOf(
                Entry(R.drawable.ic_lock, "Log in again", "Use this if videos stop opening") { open(s) },
                Entry(R.drawable.ic_delete, "Log out", "Remove the saved login from this phone", true) {
                    CookieStore.logout(this, s.id)
                    toast("Logged out of ${s.name}")
                    buildList()
                }
            )
        )
    }

    private fun askOther() {
        val pad = U.dp(this, 22)
        val box = LinearLayout(this)
        box.setPadding(pad, U.dp(this, 8), pad, 0)
        val et = EditText(this)
        et.hint = "example.com"
        et.setSingleLine(true)
        et.inputType = InputType.TYPE_TEXT_VARIATION_URI
        et.setTextColor(ContextCompat.getColor(this, R.color.text))
        et.setHintTextColor(ContextCompat.getColor(this, R.color.text2))
        box.addView(et, LinearLayout.LayoutParams(-1, -2))
        AlertDialog.Builder(this).setTitle("Website address").setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Continue") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) open(guessSite(t))
            }.show()
    }

    // ------------------------------------------------------------------ login page

    private fun open(s: CookieStore.Site) {
        current = s
        title.text = "Log in · ${s.name}"
        scroll.visibility = View.GONE
        hint.visibility = View.GONE
        webBox.visibility = View.VISIBLE
        done.visibility = View.VISIBLE
        web.loadUrl(s.start)
    }

    private fun finishLogin() {
        val s = current ?: return
        if (CookieStore.capture(this, s)) {
            toast("Logged in to ${s.name}. Now open your video link again.")
            if (fromLink) finish() else showList()
        } else {
            AlertDialog.Builder(this).setTitle("Login not finished yet")
                .setMessage("Finish signing in on the page first (password, code, \"Continue\" ...). When you can see the website's home page, tap Done again.")
                .setPositiveButton("OK", null).show()
        }
    }
}
