package com.mn.videoplayer

import android.content.Context
import androidx.media3.common.MimeTypes
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONObject

/** Finds the real, playable video address behind a website link using yt-dlp. */
object YtDlp {
    @Volatile var ready = false
    @Volatile var initError: String? = null
    @Volatile private var updated = false
    var appCtx: Context? = null

    class Found(
        val url: String,
        val title: String?,
        val headers: Map<String, String>,
        val mime: String?,
        val audioUrl: String? = null,
        val audioHeaders: Map<String, String> = emptyMap()
    )

    // Different YouTube "clients" work on different networks / days. We try them one after another.
    private val attempts: List<List<Pair<String, String>>> = listOf(
        emptyList(),
        listOf("--extractor-args" to "youtube:player_client=android_vr"),
        listOf("--extractor-args" to "youtube:player_client=tv")
    )

    private fun waitReady(): Boolean {
        var i = 0
        while (!ready && initError == null && i < 150) { // up to ~15 s
            Thread.sleep(100); i++
        }
        return ready
    }

    /** Returns the playable address, or throws an exception whose message explains the problem. */
    fun extract(link: String): Found {
        if (!waitReady()) throw IllegalStateException("The link engine could not start. ${initError ?: ""}".trim())
        var last: Exception? = null
        // 1) with the saved website login (if any), 2) without it, trying other YouTube clients
        val cf = appCtx?.let { CookieStore.file(it) }
        val plan = ArrayList<Pair<List<Pair<String, String>>, java.io.File?>>()
        if (cf != null) plan.add(emptyList<Pair<String, String>>() to cf)
        for (a in attempts) plan.add(a to null)
        for ((extra, cookies) in plan) {
            try {
                return run(link, extra, cookies)
            } catch (e: Exception) {
                last = e
                if (isFinal(e.message)) throw e
            }
        }
        // Everything failed: the site may have changed. Update yt-dlp once and try again.
        if (!updated) {
            updated = true
            try { YoutubeDL.getInstance().updateYoutubeDL(appCtx!!) } catch (_: Throwable) {}
            try { return run(link, emptyList(), cf) } catch (e: Exception) { last = e }
        }
        throw last ?: IllegalStateException("No playable video was found at this link.")
    }

    /** Problems that another try can't fix. */
    private fun isFinal(m: String?): Boolean {
        val s = (m ?: "").lowercase()
        return s.contains("unsupported url") || s.contains("drm") || s.contains("private video") ||
                s.contains("has been removed") || s.contains("video unavailable") ||
                s.contains("not available in your country") || s.contains("members-only") ||
                s.contains("unable to resolve host") || s.contains("no address associated")
    }

    private fun str(o: JSONObject, k: String): String? =
        if (o.isNull(k)) null else o.optString(k).trim().takeIf { it.isNotEmpty() && it != "null" }

    private fun hasCodec(o: JSONObject, k: String): Boolean {
        val s = str(o, k)
        return s != null && s != "none"
    }

    private fun headersOf(o: JSONObject?): Map<String, String> {
        val m = HashMap<String, String>()
        if (o == null) return m
        val it = o.keys()
        while (it.hasNext()) {
            val k = it.next()
            val v = o.optString(k)
            if (v.isNotEmpty()) m[k] = v
        }
        return m
    }

    private fun mimeOf(url: String): String? = when {
        url.contains(".m3u8", true) -> MimeTypes.APPLICATION_M3U8
        url.contains(".mpd", true) -> MimeTypes.APPLICATION_MPD
        else -> null
    }

    private class F(j: JSONObject, topHeaders: Map<String, String>) {
        val url: String = str2(j, "url") ?: ""
        val hasV = hasCodec2(j, "vcodec")
        val hasA = hasCodec2(j, "acodec")
        val h: Int = j.optInt("height", 0)
        val ext: String = str2(j, "ext") ?: ""
        val vc: String = str2(j, "vcodec") ?: ""
        val hls: Boolean = url.contains(".m3u8", true) || url.contains("/manifest/", true)
        val headers: Map<String, String> = headersOf2(j.optJSONObject("http_headers")).let { if (it.isEmpty()) topHeaders else it }
        val score: Int get() = h * 10 + (if (vc.startsWith("avc1") || vc.startsWith("h264")) 5 else if (ext == "mp4") 3 else 0)
    }

    private fun str2(o: JSONObject, k: String) = str(o, k)
    private fun hasCodec2(o: JSONObject, k: String) = hasCodec(o, k)
    private fun headersOf2(o: JSONObject?) = headersOf(o)

    private fun run(link: String, extra: List<Pair<String, String>>, cookies: java.io.File?): Found {
        val req = YoutubeDLRequest(link)
        req.addOption("--dump-single-json")
        req.addOption("--no-playlist")
        req.addOption("--playlist-items", "1")
        req.addOption("--no-warnings")
        req.addOption("--socket-timeout", "15")
        if (cookies != null) req.addOption("--cookies", cookies.absolutePath)
        for ((k, v) in extra) req.addOption(k, v)
        val resp = YoutubeDL.getInstance().execute(req)
        val out = resp.out
        if (out.isBlank()) throw IllegalStateException("The link engine gave no answer. ${resp.err}")
        return parse(out)
    }

    private fun parse(json: String): Found {
        var o = JSONObject(json)
        if (!o.isNull("entries")) {
            val arr = o.optJSONArray("entries")
            var first: JSONObject? = null
            if (arr != null) for (i in 0 until arr.length()) {
                val e = arr.optJSONObject(i)
                if (e != null) { first = e; break }
            }
            o = first ?: throw IllegalStateException("No video was found at this link.")
        }
        val title = str(o, "title")
        val top = headersOf(o.optJSONObject("http_headers"))
        val fa = o.optJSONArray("formats")
        val fs = ArrayList<F>()
        if (fa != null) for (i in 0 until fa.length()) {
            val j = fa.optJSONObject(i) ?: continue
            val f = F(j, top)
            if (f.url.startsWith("http", true)) fs.add(f)
        }
        val prog = fs.filter { it.hasV && it.hasA && !it.hls }
        val hls = fs.filter { it.hasV && it.hasA && it.hls }
        val vOnly = fs.filter { it.hasV && !it.hasA && !it.hls && it.h <= 1080 }
        val aOnly = fs.filter { !it.hasV && it.hasA && !it.hls }

        val bestProg = prog.maxByOrNull { it.score }
        val bestV = vOnly.maxByOrNull { it.score }
        // yt-dlp lists formats from worst to best, so the last one is the best
        val bestA = aOnly.lastOrNull { it.ext == "m4a" } ?: aOnly.lastOrNull()

        // HD: separate video + audio, played together (needed for YouTube 720p/1080p)
        if (bestV != null && bestA != null && (bestProg == null || bestV.h > bestProg.h)) {
            return Found(bestV.url, title, bestV.headers, mimeOf(bestV.url), bestA.url, bestA.headers)
        }
        if (bestProg != null) return Found(bestProg.url, title, bestProg.headers, mimeOf(bestProg.url))
        val bestHls = hls.maxByOrNull { it.h }
        if (bestHls != null) return Found(bestHls.url, title, bestHls.headers, MimeTypes.APPLICATION_M3U8)
        val direct = str(o, "url") ?: str(o, "manifest_url")
        if (direct != null) return Found(direct, title, top, mimeOf(direct))
        if (bestA != null) return Found(bestA.url, title, bestA.headers, mimeOf(bestA.url))
        throw IllegalStateException("No playable video was found at this link.")
    }

    /** Plain-language explanation, or null when the problem is not one we recognise. */
    fun friendly(m: String?): String? {
        val s = (m ?: "").lowercase()
        return when {
            s.contains("drm") -> "This video is DRM-protected (Netflix, Prime Video, Disney+ ...). It can't be played here."
            s.contains("not a bot") -> "YouTube is asking to confirm you are not a bot on this network. Logging in to YouTube usually fixes this."
            s.contains("not available in your country") || s.contains("geo") ->
                "This video is blocked in your country."
            s.contains("private video") || s.contains("login") || s.contains("log in") || s.contains("sign in") ||
                    s.contains("members-only") || s.contains("cookies") || s.contains("rate-limit") ->
                "This video is private, age-restricted or needs a login. Tap \"Log in\", sign in to the website, then open the link again."
            s.contains("unsupported url") -> "This website is not supported."
            s.contains("removed") || s.contains("video unavailable") || s.contains("no longer available") ->
                "This video is not available any more."
            s.contains("unable to resolve host") || s.contains("no address associated") || s.contains("timed out") ->
                "Can't reach this address. Check the link and your internet connection."
            else -> null
        }
    }

    /** True when signing in to the website could solve the problem (shows the "Log in" button). */
    fun isLoginProblem(m: String?): Boolean {
        val s = (m ?: "").lowercase()
        return listOf(
            "login", "log in", "sign in", "not a bot", "cookies", "private video", "rate-limit",
            "members-only", "confirm your age", "age-restricted", "requested content is not available"
        ).any { s.contains(it) }
    }

    /** Last meaningful line of the technical error, so problems can be reported precisely. */
    fun detail(m: String?): String {
        val t = (m ?: "").trim()
        val lines = t.lines()
        val line = lines.lastOrNull { it.contains("ERROR", true) } ?: lines.lastOrNull { it.isNotBlank() } ?: ""
        return line.trim().take(240)
    }
}
