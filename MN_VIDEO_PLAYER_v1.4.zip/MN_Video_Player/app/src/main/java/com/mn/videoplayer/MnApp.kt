package com.mn.videoplayer

import android.app.Application
import com.yausername.youtubedl_android.YoutubeDL

class MnApp : Application() {
    override fun onCreate() {
        super.onCreate()
        YtDlp.appCtx = applicationContext
        // Prepare the yt-dlp engine in the background (first start takes a few seconds)
        Thread {
            try {
                YoutubeDL.getInstance().init(this)
                YtDlp.ready = true
            } catch (e: Throwable) {
                YtDlp.initError = e.message ?: e.toString()
                return@Thread
            }
            // Sites change often: refresh the engine about once a day so links keep working
            try {
                val sp = getSharedPreferences("mnvp_engine", MODE_PRIVATE)
                val last = sp.getLong("upd", 0L)
                if (System.currentTimeMillis() - last > 24L * 3600_000L) {
                    YoutubeDL.getInstance().updateYoutubeDL(this)
                    sp.edit().putLong("upd", System.currentTimeMillis()).apply()
                }
            } catch (_: Throwable) {
            }
        }.start()
    }
}
