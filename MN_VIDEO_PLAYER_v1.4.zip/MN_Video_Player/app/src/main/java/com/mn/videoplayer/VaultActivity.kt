package com.mn.videoplayer

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

/**
 * Private vault: videos are stored inside the app's private folder (hidden from gallery and other apps)
 * and can only be opened after entering the PIN. The screen is also blocked from screenshots and
 * hidden in the recent-apps preview.
 */
class VaultActivity : AppCompatActivity() {

    private lateinit var list: RecyclerView
    private lateinit var empty: LinearLayout
    private lateinit var info: TextView
    private lateinit var adapter: RowAdapter

    private var videos: List<Video> = emptyList()
    private var unlocked = false
    private var keepUnlocked = false
    private var asking = false
    private var loaded = false

    private val deleteLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        toast(if (r.resultCode == Activity.RESULT_OK) "Moved to the vault" else "Copied to the vault. The originals were kept.")
        reload()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContentView(R.layout.activity_vault)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.vaultRoot)) { v, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            insets
        }

        list = findViewById(R.id.vList)
        empty = findViewById(R.id.vEmpty)
        info = findViewById(R.id.vInfo)
        adapter = RowAdapter({ r, _ -> onClick(r) }, { r -> onLong(r) })
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        list.itemAnimator = null

        findViewById<ImageButton>(R.id.vBack).setOnClickListener { finish() }
        findViewById<ImageButton>(R.id.vAdd).setOnClickListener { addVideos() }
        findViewById<View>(R.id.vAddBig).setOnClickListener { addVideos() }
        findViewById<ImageButton>(R.id.vMore).setOnClickListener {
            Ui.menu(
                this, null, listOf(
                    Entry(R.drawable.ic_add, "Add videos") { addVideos() },
                    Entry(R.drawable.ic_lock, "Change PIN") { changePin() },
                    Entry(R.drawable.ic_vault, "Lock now") { finish() }
                )
            )
        }
        showLocked()
    }

    override fun onStart() {
        super.onStart()
        if (keepUnlocked) {
            keepUnlocked = false
            return
        }
        if (!unlocked) unlockFlow()
    }

    override fun onStop() {
        super.onStop()
        if (!keepUnlocked) {
            unlocked = false
            showLocked()
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ lock / unlock

    private fun showLocked() {
        list.visibility = View.GONE
        empty.visibility = View.GONE
        info.visibility = View.GONE
    }

    private fun showContent() {
        info.visibility = View.VISIBLE
        if (loaded) render()
        reload()
    }

    private fun unlockFlow() {
        if (asking) return
        asking = true
        if (Prefs.hasPin()) askPin() else createPin()
    }

    private fun pinDialog(
        title: String, msg: String, action: String, autoLen: Int = 0,
        onOk: (String) -> String?, onCancel: () -> Unit
    ) {
        PinDialog(this, title, msg, action, autoLen, onOk, onCancel).show()
    }

    private fun createPin() {
        pinDialog(
            "Create your PIN",
            "Choose 4–8 digits to lock your private vault. If you forget it, the videos can't be opened again.",
            "Continue", 0,
            { p -> confirmPin(p); null },
            { asking = false; finish() }
        )
    }

    private fun confirmPin(first: String) {
        pinDialog(
            "Confirm your PIN", "Enter the same PIN once more.", "Save PIN", 0,
            { p ->
                if (p == first) {
                    Prefs.setPin(p)
                    asking = false
                    unlocked = true
                    showContent()
                    null
                } else "The PINs don't match. Try again."
            },
            { asking = false; finish() }
        )
    }

    private fun askPin() {
        val left = Prefs.vaultLockLeftMs()
        if (left > 0) {
            AlertDialog.Builder(this).setTitle("Too many wrong attempts")
                .setMessage("Please try again in ${left / 1000 + 1} seconds.")
                .setCancelable(false)
                .setPositiveButton("OK") { _, _ -> asking = false; finish() }
                .show()
            return
        }
        pinDialog(
            "Private Vault", "Enter your PIN to open your hidden videos.", "Unlock", Prefs.pinLength(),
            { p ->
                if (Prefs.checkPin(p)) {
                    asking = false
                    unlocked = true
                    showContent()
                    null
                } else if (Prefs.vaultLockLeftMs() > 0) {
                    toast("Too many wrong attempts. Try again in a moment.")
                    asking = false
                    finish()
                    null
                } else "Wrong PIN. Try again."
            },
            { asking = false; finish() }
        )
    }

    private fun changePin() {
        pinDialog(
            "Change PIN", "Enter your current PIN.", "Continue", 0,
            { p -> if (Prefs.checkPin(p)) { newPin(); null } else "Wrong PIN. Try again." },
            {}
        )
    }

    private fun newPin() {
        pinDialog(
            "New PIN", "Choose a new 4–8 digit PIN.", "Continue", 0,
            { p ->
                pinDialog(
                    "Confirm new PIN", "Enter the new PIN again.", "Save PIN", 0,
                    { c ->
                        if (c == p) {
                            Prefs.setPin(c)
                            toast("PIN changed")
                            null
                        } else "The PINs don't match. Try again."
                    },
                    {}
                )
                null
            },
            {}
        )
    }

    // ------------------------------------------------------------------ list

    private fun reload() {
        Thread {
            val v = VaultStore.list(this)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                videos = v
                loaded = true
                if (unlocked) render()
            }
        }.start()
    }

    private fun render() {
        adapter.submit(videos.map { Row.Vid(it) })
        info.text = if (videos.isEmpty()) "Videos in the vault are hidden from the gallery and from other apps. They are protected by your PIN."
        else "${videos.size} video${if (videos.size == 1) "" else "s"} · ${U.size(videos.sumOf { it.size })} · hidden from the gallery, protected by your PIN"
        if (!unlocked) {
            showLocked()
        } else if (videos.isEmpty()) {
            list.visibility = View.GONE
            empty.visibility = View.VISIBLE
        } else {
            empty.visibility = View.GONE
            list.visibility = View.VISIBLE
        }
    }

    private fun onClick(r: Row) {
        if (r !is Row.Vid) return
        val idx = videos.indexOfFirst { it.id == r.v.id }.coerceAtLeast(0)
        keepUnlocked = true
        PlayerActivity.start(
            this,
            ArrayList(videos.map { it.uri.toString() }),
            ArrayList(videos.map { it.name }),
            idx,
            true
        )
    }

    private fun onLong(r: Row) {
        if (r !is Row.Vid) return
        val v = r.v
        Ui.menu(
            this, v.name, listOf(
                Entry(R.drawable.ic_play, "Play") { onClick(r) },
                Entry(R.drawable.ic_unlock, "Take out of the vault", "Show it in your gallery again") { restore(v) },
                Entry(R.drawable.ic_info, "Video info") {
                    AlertDialog.Builder(this).setTitle("Video info").setMessage(
                        "Name: ${v.name}\nDuration: ${U.time(v.duration)}\nSize: ${U.size(v.size)}\n" +
                                (if (v.width > 0) "Resolution: ${v.width}×${v.height}" else "")
                    ).setPositiveButton("OK", null).show()
                },
                Entry(R.drawable.ic_delete, "Delete forever", danger = true) { confirmDelete(v) }
            )
        )
    }

    private fun restore(v: Video) {
        val prog = Ui.progress(this, "Taking the video out of the vault…")
        Thread {
            val ok = VaultStore.restore(this, File(v.uri.path ?: ""))
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                prog.dismiss()
                toast(if (ok) "Video is back in your gallery (Movies/MN Video Player)" else "Couldn't take the video out")
                reload()
            }
        }.start()
    }

    private fun confirmDelete(v: Video) {
        AlertDialog.Builder(this).setTitle("Delete forever?")
            .setMessage("${v.name}\n\nThis cannot be undone.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                val ok = File(v.uri.path ?: "").delete()
                toast(if (ok) "Video deleted" else "Couldn't delete this video")
                reload()
            }.show()
    }

    // ------------------------------------------------------------------ add videos

    private fun addVideos() {
        Thread {
            val lib = MediaRepo.load(this)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (lib.isEmpty()) {
                    toast("No videos found. Allow video access on the main screen first.")
                    return@runOnUiThread
                }
                PickDialog(this, lib.sortedByDescending { it.date }, "Move to vault") { chosen ->
                    if (chosen.isNotEmpty()) moveIn(chosen)
                }.show()
            }
        }.start()
    }

    private fun moveIn(chosen: List<Video>) {
        val prog = Ui.progress(this, "Preparing…")
        Thread {
            val done = ArrayList<Video>()
            for ((n, v) in chosen.withIndex()) {
                runOnUiThread { Ui.setProgressText(prog, "Copying ${n + 1} of ${chosen.size}…") }
                if (VaultStore.copyIn(this, v)) done.add(v)
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                prog.dismiss()
                if (done.isEmpty()) {
                    toast("Couldn't copy the selected videos")
                    return@runOnUiThread
                }
                if (done.size < chosen.size) toast("${chosen.size - done.size} video(s) could not be copied")
                var launched = false
                val started = Ui.requestDelete(this, done.map { it.uri }) {
                    launched = true
                    keepUnlocked = true
                    deleteLauncher.launch(it)
                }
                if (!launched) {
                    toast(if (started) "Moved to the vault" else "Copied to the vault, but the originals couldn't be removed. Delete them manually.")
                    reload()
                }
            }
        }.start()
    }
}
