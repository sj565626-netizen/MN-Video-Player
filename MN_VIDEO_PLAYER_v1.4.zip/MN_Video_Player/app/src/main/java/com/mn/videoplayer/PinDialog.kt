package com.mn.videoplayer

import android.animation.ObjectAnimator
import android.app.Dialog
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/**
 * Full-screen PIN screen with a number pad and dots.
 * [onOk] returns null when the PIN was accepted (the screen closes) or an error text to show.
 * [autoLen] > 0: the PIN is checked by itself as soon as that many digits are typed.
 */
class PinDialog(
    private val act: AppCompatActivity,
    private val title: String,
    private val subtitle: String,
    private val action: String,
    private val autoLen: Int,
    private val onOk: (String) -> String?,
    private val onCancel: () -> Unit
) {
    private val d = Dialog(act, R.style.FullDialog)
    private val sb = StringBuilder()
    private val MIN = 4
    private val MAX = 8
    private lateinit var dots: LinearLayout
    private lateinit var err: TextView
    private lateinit var btn: Button

    private fun dp(v: Int) = U.dp(act, v)

    fun show() {
        d.setContentView(R.layout.dialog_pin)
        d.setCancelable(true)
        d.setOnCancelListener { onCancel() }
        d.window?.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        d.window?.setLayout(-1, -1)

        val root = d.findViewById<View>(R.id.pinRoot)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            insets
        }
        d.findViewById<TextView>(R.id.pinTitle).text = title
        d.findViewById<TextView>(R.id.pinSub).text = subtitle
        d.findViewById<ImageButton>(R.id.pinClose).setOnClickListener { d.cancel() }
        dots = d.findViewById(R.id.pinDots)
        err = d.findViewById(R.id.pinErr)
        btn = d.findViewById(R.id.pinOk)
        btn.text = action
        btn.setOnClickListener { submit() }
        buildPad(d.findViewById(R.id.pinPad))
        refresh()
        d.show()
    }

    private fun buildPad(pad: LinearLayout) {
        val rows = listOf(
            listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("", "0", "<")
        )
        for (r in rows) {
            val row = LinearLayout(act)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER
            for (k in r) {
                val size = dp(66)
                val lp = LinearLayout.LayoutParams(size, size)
                lp.setMargins(dp(10), dp(6), dp(10), dp(6))
                val v: View = when (k) {
                    "" -> View(act)
                    "<" -> ImageView(act).apply {
                        setImageResource(R.drawable.ic_backspace)
                        setColorFilter(ContextCompat.getColor(act, R.color.text2))
                        scaleType = ImageView.ScaleType.CENTER
                        setPadding(dp(20), dp(20), dp(20), dp(20))
                        setBackgroundResource(R.drawable.bg_key)
                        setOnClickListener { back() }
                        setOnLongClickListener { sb.setLength(0); err.text = ""; refresh(); true }
                    }
                    else -> TextView(act).apply {
                        text = k
                        textSize = 26f
                        gravity = Gravity.CENTER
                        setTextColor(ContextCompat.getColor(act, R.color.text))
                        setBackgroundResource(R.drawable.bg_key)
                        setOnClickListener { press(k) }
                    }
                }
                row.addView(v, lp)
            }
            pad.addView(row)
        }
    }

    private fun press(k: String) {
        if (sb.length >= MAX) return
        sb.append(k)
        err.text = ""
        refresh()
        if (autoLen in MIN..MAX && sb.length == autoLen) submit()
    }

    private fun back() {
        if (sb.isNotEmpty()) sb.setLength(sb.length - 1)
        err.text = ""
        refresh()
    }

    private fun refresh() {
        dots.removeAllViews()
        val n = if (autoLen in MIN..MAX) autoLen else maxOf(MIN, sb.length)
        for (i in 0 until n) {
            val v = View(act)
            val lp = LinearLayout.LayoutParams(dp(14), dp(14))
            lp.setMargins(dp(7), 0, dp(7), 0)
            v.setBackgroundResource(if (i < sb.length) R.drawable.bg_dot_on else R.drawable.bg_dot_off)
            dots.addView(v, lp)
        }
        val ok = sb.length >= MIN
        btn.isEnabled = ok
        btn.alpha = if (ok) 1f else 0.4f
    }

    private fun submit() {
        if (sb.length < MIN) return
        val e = onOk(sb.toString())
        if (e == null) {
            try { d.dismiss() } catch (_: Exception) {}
        } else {
            err.text = e
            sb.setLength(0)
            refresh()
            dots.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            ObjectAnimator.ofFloat(dots, "translationX", 0f, -26f, 26f, -18f, 18f, -9f, 9f, 0f)
                .setDuration(380).start()
        }
    }
}
