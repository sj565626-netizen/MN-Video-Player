package com.mn.videoplayer

import android.content.Context
import android.webkit.CookieManager
import java.io.File

/**
 * Keeps the website logins. Only the login cookies are saved (never the password), in the app's
 * private folder. They are handed to yt-dlp so private videos of the logged-in account can play.
 */
object CookieStore {
    class Site(
        val id: String,
        val name: String,
        val start: String,
        val domains: List<String>,
        /** Any one of these cookies proves that the login worked. Empty = accept any cookie. */
        val keys: List<String>
    )

    val sites = listOf(
        Site(
            "youtube", "YouTube / Google",
            "https://accounts.google.com/ServiceLogin?service=youtube&continue=https%3A%2F%2Fwww.youtube.com%2F",
            listOf("youtube.com", "google.com"),
            listOf("SID", "__Secure-1PSID", "__Secure-3PSID", "SAPISID")
        ),
        Site("facebook", "Facebook", "https://m.facebook.com/login", listOf("facebook.com"), listOf("c_user", "xs")),
        Site("instagram", "Instagram", "https://www.instagram.com/accounts/login/", listOf("instagram.com"), listOf("sessionid")),
        Site("tiktok", "TikTok", "https://www.tiktok.com/login", listOf("tiktok.com"), listOf("sessionid", "sid_tt")),
        Site("x", "X (Twitter)", "https://x.com/i/flow/login", listOf("x.com", "twitter.com"), listOf("auth_token"))
    )

    fun customSite(host: String): Site {
        val h = host.lowercase().removePrefix("www.").removePrefix("m.")
        return Site("c_" + h.replace(Regex("[^a-z0-9.-]"), "_"), h, "https://$h", listOf(h), emptyList())
    }

    /** Sites the person added by hand and is logged in to. */
    fun customHosts(ctx: Context): List<String> =
        dir(ctx).listFiles { f -> f.name.startsWith("c_") && f.name.endsWith(".txt") }
            ?.map { it.name.removePrefix("c_").removeSuffix(".txt") }?.sorted() ?: emptyList()

    private fun dir(ctx: Context): File {
        val d = File(ctx.filesDir, "cookies")
        if (!d.exists()) d.mkdirs()
        return d
    }

    /** The combined cookie file for yt-dlp, or null when nobody is logged in. */
    fun file(ctx: Context): File? {
        val f = File(ctx.filesDir, "cookies.txt")
        return if (f.exists() && f.length() > 40) f else null
    }

    fun isLoggedIn(ctx: Context, id: String) = File(dir(ctx), "$id.txt").exists()

    /** Reads the cookies the login page left in the WebView. Returns false if the login is not finished. */
    fun capture(ctx: Context, site: Site): Boolean {
        val cm = CookieManager.getInstance()
        cm.flush()
        val exp = System.currentTimeMillis() / 1000 + 365L * 24 * 3600
        val sb = StringBuilder()
        val names = HashSet<String>()
        for (d in site.domains) {
            val merged = LinkedHashMap<String, String>()
            for (u in listOf("https://$d", "https://www.$d", "https://m.$d")) {
                val c = cm.getCookie(u) ?: continue
                for (part in c.split(";")) {
                    val t = part.trim()
                    val i = t.indexOf('=')
                    if (i <= 0) continue
                    merged[t.substring(0, i)] = t.substring(i + 1)
                }
            }
            for ((n, v) in merged) {
                names.add(n)
                sb.append(".").append(d).append("\tTRUE\t/\tTRUE\t").append(exp).append("\t")
                    .append(n).append("\t").append(v).append("\n")
            }
        }
        if (names.isEmpty()) return false
        if (site.keys.isNotEmpty() && site.keys.none { names.contains(it) }) return false
        File(dir(ctx), "${site.id}.txt").writeText(sb.toString())
        rebuild(ctx)
        return true
    }

    fun logout(ctx: Context, id: String) {
        File(dir(ctx), "$id.txt").delete()
        rebuild(ctx)
        try {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
        } catch (_: Exception) {
        }
    }

    private fun rebuild(ctx: Context) {
        val files = dir(ctx).listFiles { f -> f.name.endsWith(".txt") } ?: emptyArray()
        val out = File(ctx.filesDir, "cookies.txt")
        if (files.isEmpty()) {
            out.delete()
            return
        }
        val sb = StringBuilder("# Netscape HTTP Cookie File\n")
        for (f in files) sb.append(f.readText())
        out.writeText(sb.toString())
    }
}
