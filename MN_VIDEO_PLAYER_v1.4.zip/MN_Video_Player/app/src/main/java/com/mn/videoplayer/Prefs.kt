package com.mn.videoplayer

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.UUID

object Prefs {
    private var sp: SharedPreferences? = null

    fun init(c: Context) {
        if (sp == null) sp = c.applicationContext.getSharedPreferences("mnvp", Context.MODE_PRIVATE)
    }

    private fun s(): SharedPreferences = sp!!

    private fun bool(k: String, d: Boolean) = s().getBoolean(k, d)
    private fun setBool(k: String, v: Boolean) = s().edit().putBoolean(k, v).apply()

    var resume: Boolean
        get() = bool("resume", true)
        set(v) = setBool("resume", v)
    var autoNext: Boolean
        get() = bool("autoNext", true)
        set(v) = setBool("autoNext", v)
    var bgPlay: Boolean
        get() = bool("bgPlay", false)
        set(v) = setBool("bgPlay", v)
    var autoPip: Boolean
        get() = bool("autoPip", true)
        set(v) = setBool("autoPip", v)
    var autoRotate: Boolean
        get() = bool("autoRotate", true)
        set(v) = setBool("autoRotate", v)
    var gestures: Boolean
        get() = bool("gestures", true)
        set(v) = setBool("gestures", v)
    var seekStep: Int
        get() = s().getInt("seekStep", 10)
        set(v) = s().edit().putInt("seekStep", v).apply()
    var subSize: Int
        get() = s().getInt("subSize", 100)
        set(v) = s().edit().putInt("subSize", v).apply()
    var gridView: Boolean
        get() = bool("grid", false)
        set(v) = setBool("grid", v)
    var sortMode: Int
        get() = s().getInt("sort", 2)
        set(v) = s().edit().putInt("sort", v).apply()
    var eqOn: Boolean
        get() = bool("eqOn", false)
        set(v) = setBool("eqOn", v)
    var eqLevels: String
        get() = s().getString("eqLevels", "") ?: ""
        set(v) = s().edit().putString("eqLevels", v).apply()
    var subColor: Int
        get() = s().getInt("subColor", 0xFFFFFFFF.toInt())
        set(v) = s().edit().putInt("subColor", v).apply()
    var boost: Int
        get() = s().getInt("boost", 0)
        set(v) = s().edit().putInt("boost", v).apply()

    fun getPos(uri: String): Long = s().getLong("p_" + U.key(uri), 0L)
    fun setPos(uri: String, p: Long) = s().edit().putLong("p_" + U.key(uri), p).apply()

    fun history(): List<HistoryEntry> {
        val out = ArrayList<HistoryEntry>()
        try {
            val arr = JSONArray(s().getString("history", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(HistoryEntry(o.getString("u"), o.getString("t"), o.getLong("w"), o.optLong("d", 0L)))
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun addHistory(uri: String, title: String, duration: Long) {
        val list = history().filter { it.uri != uri }.toMutableList()
        list.add(0, HistoryEntry(uri, title, System.currentTimeMillis(), duration))
        while (list.size > 60) list.removeAt(list.size - 1)
        val arr = JSONArray()
        for (h in list) {
            val o = JSONObject()
            o.put("u", h.uri); o.put("t", h.title); o.put("w", h.time); o.put("d", h.duration)
            arr.put(o)
        }
        s().edit().putString("history", arr.toString()).apply()
    }

    fun clearHistory() = s().edit().putString("history", "[]").apply()

    var defaultSpeed: Float
        get() = s().getFloat("defSpeed", 1f)
        set(v) = s().edit().putFloat("defSpeed", v).apply()

    // ---- favorites
    fun isFav(uri: String): Boolean = s().getStringSet("fav", null)?.contains(uri) == true

    fun toggleFav(uri: String): Boolean {
        val set = HashSet(s().getStringSet("fav", emptySet()) ?: emptySet())
        val added = if (set.contains(uri)) { set.remove(uri); false } else { set.add(uri); true }
        s().edit().putStringSet("fav", set).apply()
        return added
    }

    fun hasFavs(): Boolean = (s().getStringSet("fav", null)?.size ?: 0) > 0

    // ---- vault PIN (stored as salted SHA-256, never in plain text)
    private fun hashPin(salt: String, pin: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun hasPin(): Boolean = s().getString("vh", null) != null

    fun setPin(pin: String) {
        val salt = UUID.randomUUID().toString()
        s().edit().putString("vs", salt).putString("vh", hashPin(salt, pin))
            .putInt("vf", 0).putLong("vl", 0L).putInt("vn", pin.length).apply()
    }

    fun pinLength(): Int = s().getInt("vn", 0)

    fun vaultLockLeftMs(): Long = maxOf(0L, s().getLong("vl", 0L) - System.currentTimeMillis())

    fun checkPin(pin: String): Boolean {
        val salt = s().getString("vs", "") ?: ""
        val ok = hashPin(salt, pin) == s().getString("vh", null)
        val e = s().edit()
        if (ok) {
            e.putInt("vf", 0)
        } else {
            val f = s().getInt("vf", 0) + 1
            if (f >= 5) {
                e.putInt("vf", 0).putLong("vl", System.currentTimeMillis() + 30_000L)
            } else {
                e.putInt("vf", f)
            }
        }
        e.apply()
        return ok
    }
}
