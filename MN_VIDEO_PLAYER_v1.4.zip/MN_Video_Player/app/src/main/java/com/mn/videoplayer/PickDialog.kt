package com.mn.videoplayer

import android.app.Dialog
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.DateFormat
import java.util.Date

private class PickVH(v: View) : RecyclerView.ViewHolder(v) {
    val thumb: ImageView = v.findViewById(R.id.pThumb)
    val badge: TextView = v.findViewById(R.id.pBadge)
    val title: TextView = v.findViewById(R.id.pTitle)
    val sub: TextView = v.findViewById(R.id.pSub)
    val meta: TextView = v.findViewById(R.id.pMeta)
    val check: ImageView = v.findViewById(R.id.pCheck)
}

/** Full-screen video picker: thumbnail, name, duration, size, resolution and a tick for every video. */
class PickDialog(
    private val act: AppCompatActivity,
    private val items: List<Video>,
    private val goText: String,
    private val onPick: (List<Video>) -> Unit
) {
    private val d = Dialog(act, R.style.FullDialog)
    private val sel = HashSet<Int>()
    private val dateFmt = DateFormat.getDateInstance(DateFormat.MEDIUM)
    private lateinit var count: TextView
    private lateinit var all: TextView
    private lateinit var go: Button
    private lateinit var adapter: RecyclerView.Adapter<PickVH>

    fun show() {
        d.setContentView(R.layout.dialog_pick)
        d.window?.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        d.window?.setLayout(-1, -1)
        ViewCompat.setOnApplyWindowInsetsListener(d.findViewById(R.id.pickRoot)) { v, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            insets
        }
        count = d.findViewById(R.id.pickCount)
        all = d.findViewById(R.id.pickAll)
        go = d.findViewById(R.id.pickGo)
        d.findViewById<ImageButton>(R.id.pickClose).setOnClickListener { d.dismiss() }

        adapter = object : RecyclerView.Adapter<PickVH>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PickVH =
                PickVH(LayoutInflater.from(parent.context).inflate(R.layout.item_pick, parent, false))

            override fun getItemCount() = items.size

            override fun onBindViewHolder(h: PickVH, position: Int) {
                val v = items[position]
                h.title.text = v.name
                h.sub.text = U.time(v.duration) + "  ·  " + U.size(v.size) +
                        (if (v.width > 0) "  ·  ${v.width}×${v.height}" else "")
                val ms = if (v.date > 100_000_000_000L) v.date else v.date * 1000
                h.meta.text = v.folder + (if (v.date > 0) "  ·  " + dateFmt.format(Date(ms)) else "")
                h.badge.text = U.time(v.duration)
                Thumbs.load(act, v.uri, h.thumb)
                val on = sel.contains(position)
                h.check.setImageResource(if (on) R.drawable.ic_check_on else R.drawable.ic_check_off)
                h.itemView.setBackgroundColor(if (on) 0x2238BDF8 else Color.TRANSPARENT)
                h.itemView.setOnClickListener {
                    val p = h.bindingAdapterPosition
                    if (p < 0) return@setOnClickListener
                    if (!sel.add(p)) sel.remove(p)
                    notifyItemChanged(p)
                    updateBar()
                }
            }
        }
        val list = d.findViewById<RecyclerView>(R.id.pickList)
        list.layoutManager = LinearLayoutManager(act)
        list.adapter = adapter
        list.itemAnimator = null

        all.setOnClickListener {
            if (sel.size == items.size) sel.clear() else { sel.clear(); sel.addAll(items.indices) }
            adapter.notifyDataSetChanged()
            updateBar()
        }
        go.setOnClickListener {
            if (sel.isEmpty()) return@setOnClickListener
            val chosen = sel.sorted().map { items[it] }
            d.dismiss()
            onPick(chosen)
        }
        updateBar()
        d.show()
    }

    private fun updateBar() {
        val n = sel.size
        var total = 0L
        for (i in sel) total += items[i].size
        count.text = if (n == 0) "${items.size} videos · tap to select" else "$n selected · ${U.size(total)}"
        all.text = if (n == items.size && n > 0) "Clear" else "Select all"
        go.text = if (n == 0) "Select videos to hide" else "$goText ($n)"
        go.isEnabled = n > 0
        go.alpha = if (n > 0) 1f else 0.45f
    }
}
