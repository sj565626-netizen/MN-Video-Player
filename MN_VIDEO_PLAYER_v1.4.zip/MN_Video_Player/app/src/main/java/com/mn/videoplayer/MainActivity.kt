package com.mn.videoplayer

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var list: RecyclerView
    private lateinit var adapter: RowAdapter
    private lateinit var emptyView: LinearLayout
    private lateinit var emptyText: TextView
    private lateinit var btnGrant: Button
    private lateinit var searchBox: EditText
    private lateinit var resumeBar: LinearLayout
    private lateinit var resumeText: TextView
    private lateinit var btnView: ImageButton
    private lateinit var tabs: List<TextView>
    private lateinit var lm: GridLayoutManager

    private val io = Executors.newSingleThreadExecutor()
    private var videos: List<Video> = emptyList()
    private var tab = 0
    private var folder: String? = null
    private var query = ""
    private var resumeEntry: HistoryEntry? = null
    private var movingToVault = false

    private val backCb = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            if (searchBox.visibility == View.VISIBLE) {
                closeSearch()
            } else if (folder != null) {
                folder = null
                render()
            }
        }
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) load() else showEmpty("MN Video Player needs access to your videos to show your library.", true)
    }
    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            val name = U.nameOf(this, uri)
            PlayerActivity.start(this, arrayListOf(uri.toString()), arrayListOf(name), 0)
        }
    }
    private val deleteLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (movingToVault) {
            movingToVault = false
            Toast.makeText(
                this,
                if (r.resultCode == Activity.RESULT_OK) "Moved to the vault" else "Copied to the vault. The original was kept.",
                Toast.LENGTH_LONG
            ).show()
        } else if (r.resultCode == Activity.RESULT_OK) {
            Toast.makeText(this, "Video deleted", Toast.LENGTH_SHORT).show()
        }
        load()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        setContentView(R.layout.activity_main)

        // Keep the whole screen inside the safe area (status bar, camera cut-out, navigation bar).
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.mainRoot)) { v, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            insets
        }

        list = findViewById(R.id.list)
        emptyView = findViewById(R.id.emptyView)
        emptyText = findViewById(R.id.emptyText)
        btnGrant = findViewById(R.id.btnGrant)
        searchBox = findViewById(R.id.searchBox)
        resumeBar = findViewById(R.id.resumeBar)
        resumeText = findViewById(R.id.resumeText)
        btnView = findViewById(R.id.btnView)
        tabs = listOf(
            findViewById(R.id.tab0), findViewById(R.id.tab1), findViewById(R.id.tab2),
            findViewById(R.id.tab3), findViewById(R.id.tab4)
        )

        adapter = RowAdapter({ r, _ -> onRowClick(r) }, { r -> onRowLong(r) })
        lm = GridLayoutManager(this, 1)
        lm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (adapter.grid && !adapter.isHeader(position) && adapter.isVideo(position)) 1 else lm.spanCount
            }
        }
        list.layoutManager = lm
        list.adapter = adapter
        list.itemAnimator = null

        tabs.forEachIndexed { i, t ->
            t.setOnClickListener {
                if (i == 4) {
                    Ui.openVault(this)
                } else {
                    tab = i
                    folder = null
                    render()
                }
            }
        }
        findViewById<ImageButton>(R.id.btnSearch).setOnClickListener { toggleSearch() }
        findViewById<ImageButton>(R.id.btnSort).setOnClickListener { showSort() }
        btnView.setOnClickListener {
            Prefs.gridView = !Prefs.gridView
            render()
        }
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener { showSettings() }
        btnGrant.setOnClickListener { ensurePermission() }
        resumeBar.setOnClickListener { resumeEntry?.let { playEntry(it) } }
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim() ?: ""
                render()
            }
        })
        onBackPressedDispatcher.addCallback(this, backCb)
        ensurePermission()
    }

    override fun onResume() {
        super.onResume()
        if (hasPermission()) load() else render()
    }

    private fun perm() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
    else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasPermission() = ContextCompat.checkSelfPermission(this, perm()) == PackageManager.PERMISSION_GRANTED

    private fun ensurePermission() {
        if (hasPermission()) load() else permLauncher.launch(perm())
    }

    private fun load() {
        io.execute {
            val v = MediaRepo.load(this)
            runOnUiThread {
                videos = v
                render()
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun showEmpty(msg: String, grant: Boolean) {
        emptyText.text = msg
        btnGrant.visibility = if (grant) View.VISIBLE else View.GONE
        emptyView.visibility = View.VISIBLE
        list.visibility = View.GONE
    }

    private fun sorted(src: List<Video>): List<Video> = when (Prefs.sortMode) {
        0 -> src.sortedBy { it.name.lowercase() }
        1 -> src.sortedByDescending { it.name.lowercase() }
        2 -> src.sortedByDescending { it.date }
        3 -> src.sortedBy { it.date }
        4 -> src.sortedByDescending { it.size }
        5 -> src.sortedBy { it.size }
        6 -> src.sortedByDescending { it.duration }
        else -> src.sortedBy { it.duration }
    }

    private fun filtered(): List<Video> {
        var src = videos
        val f = folder
        if (f != null) {
            src = if (f == FAV_FOLDER) src.filter { Prefs.isFav(it.uri.toString()) }
            else src.filter { it.folder == f }
        }
        if (query.isNotEmpty()) src = src.filter { it.name.contains(query, ignoreCase = true) }
        return sorted(src)
    }

    private fun render() {
        tabs.forEachIndexed { i, t ->
            val c = ContextCompat.getColor(this, if (i == tab) R.color.accent else R.color.text2)
            t.setTextColor(c)
            t.compoundDrawableTintList = ColorStateList.valueOf(c)
            t.background = if (i == tab) ContextCompat.getDrawable(this, R.drawable.bg_tab_on) else null
        }
        val grid = Prefs.gridView && (tab == 0 || (tab == 1 && folder != null))
        adapter.grid = grid
        lm.spanCount = if (grid) 2 else 1
        btnView.setImageResource(if (Prefs.gridView) R.drawable.ic_list else R.drawable.ic_grid)

        val rows = ArrayList<Row>()
        var emptyMsg = "No videos found"
        when (tab) {
            0 -> {
                filtered().forEach { rows.add(Row.Vid(it)) }
            }
            1 -> {
                if (folder == null) {
                    val vis = videos.filter { query.isEmpty() || it.name.contains(query, true) }
                    val favs = vis.filter { Prefs.isFav(it.uri.toString()) }
                    if (favs.isNotEmpty()) rows.add(Row.Folder(FAV_FOLDER, favs.size, favs.sumOf { it.size }))
                    val groups = vis.groupBy { it.folder }
                    groups.keys.sortedBy { it.lowercase() }.forEach { k ->
                        val g = groups[k]!!
                        rows.add(Row.Folder(k, g.size, g.sumOf { it.size }))
                    }
                } else {
                    filtered().forEach { rows.add(Row.Vid(it)) }
                }
            }
            2 -> {
                rows.add(Row.Action(R.drawable.ic_link, "Open network stream", "Type or paste a video link (HTTP, HLS, DASH, RTSP)", 1))
                rows.add(Row.Action(R.drawable.ic_paste, "Play link from clipboard", "Play a link you just copied", 4))
                rows.add(Row.Action(R.drawable.ic_folder, "Browse files", "Pick a video from any folder or cloud storage", 2))
                val streams = Prefs.history().filter { it.uri.startsWith("http") || it.uri.startsWith("rtsp") }
                if (streams.isNotEmpty()) {
                    rows.add(Row.Header("RECENT STREAMS"))
                    streams.forEach { rows.add(Row.Hist(it)) }
                }
            }
            else -> {
                val h = Prefs.history()
                if (h.isNotEmpty()) {
                    rows.add(Row.Action(R.drawable.ic_delete, "Clear history", "Remove all recently played items", 3))
                    h.forEach { rows.add(Row.Hist(it)) }
                } else emptyMsg = "Nothing played yet"
            }
        }
        adapter.submit(rows)
        val needPerm = !hasPermission() && (tab == 0 || tab == 1)
        if (needPerm) {
            showEmpty("MN Video Player needs access to your videos to show your library.", true)
        } else if (rows.isEmpty()) {
            showEmpty(emptyMsg, false)
        } else {
            emptyView.visibility = View.GONE
            list.visibility = View.VISIBLE
        }
        backCb.isEnabled = folder != null || searchBox.visibility == View.VISIBLE
        updateResumeBar()
    }

    private fun updateResumeBar() {
        val h = Prefs.history().firstOrNull {
            val p = Prefs.getPos(it.uri)
            p > 5000 && it.duration > 0 && p < it.duration * 0.95
        }
        resumeEntry = h
        if (h == null) {
            resumeBar.visibility = View.GONE
        } else {
            resumeBar.visibility = View.VISIBLE
            resumeText.text = "Continue watching\n${h.title} · ${U.time(Prefs.getPos(h.uri))}"
        }
    }

    private fun onRowClick(r: Row) {
        when (r) {
            is Row.Vid -> {
                val vs = filtered()
                val idx = vs.indexOfFirst { it.id == r.v.id }.coerceAtLeast(0)
                PlayerActivity.start(
                    this,
                    ArrayList(vs.map { it.uri.toString() }),
                    ArrayList(vs.map { it.name }),
                    idx
                )
            }
            is Row.Folder -> {
                folder = r.name
                render()
            }
            is Row.Hist -> playEntry(r.h)
            is Row.Action -> when (r.id) {
                1 -> askUrl()
                2 -> pickFile.launch(arrayOf("video/*"))
                3 -> {
                    Prefs.clearHistory()
                    render()
                }
                4 -> {
                    val t = clipText()
                    if (t != null && looksLikeLink(t)) playStream(t) else toast("No video link found in the clipboard")
                }
            }
            is Row.Header -> {}
        }
    }

    private fun playEntry(h: HistoryEntry) {
        // Website links give a new video address every time, so open them again through the link checker
        if (h.uri.startsWith("http", true)) {
            playStream(h.uri)
            return
        }
        PlayerActivity.start(this, arrayListOf(h.uri), arrayListOf(h.title), 0)
    }

    private fun onRowLong(r: Row) {
        if (r !is Row.Vid) return
        val v = r.v
        val fav = Prefs.isFav(v.uri.toString())
        Ui.menu(
            this, v.name, listOf(
                Entry(R.drawable.ic_play, "Play") { onRowClick(r) },
                Entry(
                    if (fav) R.drawable.ic_star_outline else R.drawable.ic_star,
                    if (fav) "Remove from favorites" else "Add to favorites"
                ) {
                    Prefs.toggleFav(v.uri.toString())
                    render()
                },
                Entry(R.drawable.ic_vault, "Move to private vault", "Hide it behind your PIN") { moveToVault(v) },
                Entry(R.drawable.ic_share, "Share") {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "video/*"
                        putExtra(Intent.EXTRA_STREAM, v.uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(send, "Share video"))
                },
                Entry(R.drawable.ic_info, "Video info") {
                    AlertDialog.Builder(this).setTitle("Video info").setMessage(
                        "Name: ${v.name}\nFolder: ${v.folder}\nDuration: ${U.time(v.duration)}\n" +
                                "Size: ${U.size(v.size)}\nResolution: ${v.width}×${v.height}"
                    ).setPositiveButton("OK", null).show()
                },
                Entry(R.drawable.ic_delete, "Delete", danger = true) { confirmDelete(v) }
            )
        )
    }

    private fun moveToVault(v: Video) {
        if (!Prefs.hasPin()) {
            toast("Create your vault PIN first, then move the video")
            Ui.openVault(this)
            return
        }
        val prog = Ui.progress(this, "Moving to the vault…")
        Thread {
            val ok = VaultStore.copyIn(this, v)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                prog.dismiss()
                if (!ok) {
                    toast("Couldn't copy this video to the vault")
                    return@runOnUiThread
                }
                val started = Ui.requestDelete(this, listOf(v.uri)) {
                    movingToVault = true
                    deleteLauncher.launch(it)
                }
                if (Build.VERSION.SDK_INT >= 30) {
                    if (!started) toast("Copied to the vault, but the original couldn't be removed. Delete it manually.")
                } else if (started) {
                    toast("Moved to the vault")
                    load()
                } else {
                    toast("Copied to the vault, but the original couldn't be removed. Delete it manually.")
                }
            }
        }.start()
    }

    private fun confirmDelete(v: Video) {
        AlertDialog.Builder(this).setTitle("Delete video?").setMessage(v.name)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                try {
                    if (Build.VERSION.SDK_INT >= 30) {
                        val pi = MediaStore.createDeleteRequest(contentResolver, listOf(v.uri))
                        deleteLauncher.launch(androidx.activity.result.IntentSenderRequest.Builder(pi.intentSender).build())
                    } else {
                        val n = contentResolver.delete(v.uri, null, null)
                        if (n > 0) load() else Toast.makeText(this, "Could not delete this video", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Delete is not available for this file", Toast.LENGTH_SHORT).show()
                }
            }.show()
    }

    // ------------------------------------------------------------------ network streams

    private fun clipText(): String? {
        return try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim()
        } catch (_: Exception) {
            null
        }
    }

    private fun looksLikeLink(s: String): Boolean {
        val l = s.lowercase()
        return l.startsWith("http://") || l.startsWith("https://") || l.startsWith("rtsp://") || l.startsWith("rtmp://")
    }

    private fun askUrl() {
        val pad = U.dp(this, 20)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, U.dp(this, 8), pad, 0)
        val input = EditText(this)
        input.hint = "https://example.com/video.mp4"
        input.setTextColor(ContextCompat.getColor(this, R.color.text))
        input.setHintTextColor(ContextCompat.getColor(this, R.color.text2))
        input.inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
        input.setSingleLine(true)
        val clip = clipText()
        if (clip != null && looksLikeLink(clip)) {
            input.setText(clip)
            input.setSelection(clip.length)
        }
        box.addView(input, LinearLayout.LayoutParams(-1, -2))
        val help = TextView(this)
        help.text = "Paste any link: YouTube, Facebook, Instagram, TikTok, X, Vimeo and 1000+ other sites, " +
                "direct files (.mp4, .mkv, .webm), HLS (.m3u8), DASH (.mpd) and RTSP. " +
                "Private, login-only or DRM-protected videos can't be played."
        help.setTextColor(ContextCompat.getColor(this, R.color.text2))
        help.textSize = 12f
        help.setPadding(0, U.dp(this, 10), 0, 0)
        box.addView(help)
        val loginLink = TextView(this)
        loginLink.text = "Private video? Log in to a website  ›"
        loginLink.setTextColor(ContextCompat.getColor(this, R.color.accent))
        loginLink.textSize = 13f
        loginLink.setTypeface(loginLink.typeface, android.graphics.Typeface.BOLD)
        loginLink.setPadding(0, U.dp(this, 12), 0, U.dp(this, 4))
        loginLink.setOnClickListener { LoginActivity.start(this, null) }
        box.addView(loginLink)

        val dlg = AlertDialog.Builder(this).setTitle("Network stream").setView(box)
            .setNeutralButton("Paste", null)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Play", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val t = clipText()
                if (t.isNullOrEmpty()) {
                    toast("Clipboard is empty")
                } else {
                    input.setText(t)
                    input.setSelection(t.length)
                }
            }
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val u = input.text.toString().trim()
                if (u.isEmpty()) {
                    input.error = "Enter a link"
                } else {
                    dlg.dismiss()
                    playStream(u)
                }
            }
        }
        dlg.show()
    }

    /** Checks the link first, so errors are explained in plain words instead of a player error code. */
    private fun playStream(raw: String) {
        val prog = Ui.progress(this, "Getting the video… (first time can take a few seconds)")
        Thread {
            val r = StreamResolver.resolve(raw)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                prog.dismiss()
                when (r) {
                    is StreamResolver.Result.Ok -> {
                        r.mime?.let { StreamHints.mime[r.url] = it }
                        if (r.headers.isNotEmpty()) StreamHints.headers[r.url] = r.headers
                        r.audioUrl?.let { a ->
                            StreamHints.audio[r.url] = a
                            if (r.audioHeaders.isNotEmpty()) StreamHints.headers[a] = r.audioHeaders
                        }
                        var typed = raw.trim().replace(" ", "")
                        if (!typed.contains("://")) typed = "https://$typed"
                        StreamHints.origin[r.url] = typed
                        PlayerActivity.start(this, arrayListOf(r.url), arrayListOf(r.title ?: StreamResolver.titleOf(r.url)), 0)
                    }
                    is StreamResolver.Result.Fail -> {
                        val b = AlertDialog.Builder(this).setTitle("Can't play this link").setMessage(r.message)
                            .setPositiveButton("OK", null)
                        if (r.needsLogin) b.setNeutralButton("Log in") { _, _ -> LoginActivity.start(this, raw) }
                        b.show()
                    }
                }
            }
        }.start()
    }

    // ------------------------------------------------------------------ search / sort

    private fun toggleSearch() {
        if (searchBox.visibility == View.VISIBLE) {
            closeSearch()
        } else {
            searchBox.visibility = View.VISIBLE
            searchBox.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(searchBox, 0)
            backCb.isEnabled = true
        }
    }

    private fun closeSearch() {
        searchBox.setText("")
        searchBox.visibility = View.GONE
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(searchBox.windowToken, 0)
        query = ""
        render()
    }

    private fun showSort() {
        val items = arrayOf(
            "Name (A–Z)", "Name (Z–A)", "Newest first", "Oldest first",
            "Largest first", "Smallest first", "Longest first", "Shortest first"
        )
        AlertDialog.Builder(this).setTitle("Sort by")
            .setSingleChoiceItems(items, Prefs.sortMode) { d, i ->
                Prefs.sortMode = i
                d.dismiss()
                render()
            }.show()
    }

    // ------------------------------------------------------------------ settings

    private fun spd(f: Float): String = (if (f == f.toInt().toFloat()) f.toInt().toString() else f.toString()) + "x"

    private fun showSettings() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, U.dp(this, 2), 0, U.dp(this, 8))
        val sv = ScrollView(this)
        sv.addView(box)
        val dlg = AlertDialog.Builder(this).setTitle("Settings").setView(sv)
            .setPositiveButton("Close", null).create()

        fun section(t: String) {
            box.addView(Ui.header(this, t))
        }

        fun toggle(icon: Int, title: String, sub: String, get: () -> Boolean, set: (Boolean) -> Unit) {
            val r = Ui.row(this, icon, title, sub)
            val sw = r.findViewById<SwitchCompat>(R.id.sSwitch)
            sw.visibility = View.VISIBLE
            sw.isChecked = get()
            sw.setOnCheckedChangeListener { _, on -> set(on) }
            r.setOnClickListener { sw.toggle() }
            box.addView(r)
        }

        fun value(icon: Int, title: String, sub: String, cur: () -> String, next: () -> Unit) {
            val r = Ui.row(this, icon, title, sub)
            val tv = r.findViewById<TextView>(R.id.sValue)
            tv.visibility = View.VISIBLE
            tv.text = cur()
            r.setOnClickListener {
                next()
                tv.text = cur()
            }
            box.addView(r)
        }

        fun action(icon: Int, title: String, sub: String, danger: Boolean = false, run: () -> Unit) {
            val r = Ui.row(this, icon, title, sub, danger)
            r.findViewById<View>(R.id.sChevron).visibility = View.VISIBLE
            r.setOnClickListener { run() }
            box.addView(r)
        }

        section("PLAYBACK")
        toggle(R.drawable.ic_history, "Resume playback", "Continue from where you stopped",
            { Prefs.resume }, { Prefs.resume = it })
        toggle(R.drawable.ic_next, "Play next video", "Start the next video automatically",
            { Prefs.autoNext }, { Prefs.autoNext = it })
        val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        value(R.drawable.ic_speed, "Default speed", "Speed used when a video starts",
            { spd(Prefs.defaultSpeed) }) {
            val k = speeds.indexOfFirst { abs(it - Prefs.defaultSpeed) < 0.01f }
            Prefs.defaultSpeed = speeds[(k + 1) % speeds.size]
        }

        section("CONTROLS")
        toggle(R.drawable.ic_gesture, "Gesture controls", "Swipe for volume, brightness and seeking",
            { Prefs.gestures }, { Prefs.gestures = it })
        val steps = intArrayOf(5, 10, 15, 30)
        value(R.drawable.ic_forward, "Double-tap seek", "Seconds to skip on double tap",
            { "${Prefs.seekStep} s" }) {
            val k = steps.indexOf(Prefs.seekStep)
            Prefs.seekStep = steps[(k + 1) % steps.size]
        }

        section("SCREEN")
        toggle(R.drawable.ic_rotate, "Auto-rotate", "Turn the screen to match the video",
            { Prefs.autoRotate }, { Prefs.autoRotate = it })
        val sizes = intArrayOf(70, 85, 100, 125, 150, 200)
        value(R.drawable.ic_textsize, "Subtitle size", "Tap to change the text size",
            { "${Prefs.subSize}%" }) {
            val k = sizes.indexOf(Prefs.subSize)
            Prefs.subSize = sizes[(k + 1) % sizes.size]
        }

        section("BACKGROUND")
        toggle(R.drawable.ic_headphones, "Play in background", "Keep playing sound when the screen is off",
            { Prefs.bgPlay }, { Prefs.bgPlay = it })
        toggle(R.drawable.ic_pip, "Picture-in-picture", "Small floating window when you press Home",
            { Prefs.autoPip }, { Prefs.autoPip = it })

        section("PRIVACY")
        action(R.drawable.ic_vault, "Private vault", "Hide videos behind a PIN") {
            dlg.dismiss()
            Ui.openVault(this)
        }
        action(R.drawable.ic_delete, "Clear watch history", "Remove recently played items", true) {
            AlertDialog.Builder(this).setTitle("Clear watch history?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear") { _, _ ->
                    Prefs.clearHistory()
                    render()
                    toast("History cleared")
                }.show()
        }

        section("ABOUT")
        action(R.drawable.ic_info, "About MN Video Player", "Version 1.1") {
            AlertDialog.Builder(this).setTitle("MN Video Player")
                .setMessage("Version 1.1\nA fast, clean video player with gestures, subtitles, audio tracks, equalizer, picture-in-picture, network streaming and a private vault.")
                .setPositiveButton("OK", null).show()
        }
        dlg.show()
    }
}
