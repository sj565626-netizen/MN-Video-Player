package com.mn.videoplayer

import android.net.Uri
import androidx.media3.common.MimeTypes
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.util.concurrent.ConcurrentHashMap
import javax.net.ssl.SSLException

/** Remembers the stream type we detected for links that have no file extension. */
object StreamHints {
    val mime = ConcurrentHashMap<String, String>()
}

/**
 * Checks a link BEFORE playing it, so the user gets a clear message instead of a cryptic player error.
 * - follows redirects (also http -> https)
 * - detects HLS / DASH / plain video even when the URL has no extension
 * - finds the real video inside simple web pages (og:video, <video>, .m3u8/.mp4 links)
 * - explains clearly when the link is a website page (YouTube, Facebook ...) and not a video file
 */
object StreamResolver {
    const val UA = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0 Mobile Safari/537.36"

    sealed class Result {
        data class Ok(val url: String, val mime: String?) : Result()
        data class Fail(val message: String) : Result()
    }

    private val siteHosts = listOf(
        "youtube.com", "youtu.be", "facebook.com", "fb.watch", "instagram.com",
        "tiktok.com", "twitter.com", "x.com", "dailymotion.com", "twitch.tv"
    )

    private val mediaExt = listOf(
        "m3u8", "mpd", "mp4", "m4v", "mkv", "webm", "mov", "avi", "ts", "flv", "3gp",
        "mp3", "m4a", "aac", "ogg", "oga", "wav", "opus", "flac"
    )

    private fun pathOf(url: String): String = url.substringBefore('#').substringBefore('?').lowercase()

    fun guessMime(url: String): String? {
        if (!url.startsWith("http", ignoreCase = true)) return null
        val p = pathOf(url)
        return when {
            p.endsWith(".m3u8") -> MimeTypes.APPLICATION_M3U8
            p.endsWith(".mpd") -> MimeTypes.APPLICATION_MPD
            else -> null
        }
    }

    private fun hasMediaExt(url: String): Boolean {
        val p = pathOf(url)
        return mediaExt.any { p.endsWith(".$it") }
    }

    fun titleOf(url: String): String {
        val u = Uri.parse(url)
        val seg = u.lastPathSegment
        return if (!seg.isNullOrBlank() && seg.length > 1) Uri.decode(seg) else (u.host ?: url)
    }

    fun resolve(raw: String): Result {
        var url = raw.trim().replace(" ", "")
        if (url.isEmpty()) return Result.Fail("Please enter a link.")
        if (!url.contains("://")) url = "https://$url"
        val lower = url.lowercase()
        if (lower.startsWith("rtsp://")) return Result.Ok(url, null)
        if (lower.startsWith("rtmp://")) {
            return Result.Fail("RTMP links are not supported. Use an HTTP/HTTPS link, HLS (.m3u8), DASH (.mpd) or RTSP.")
        }
        if (!lower.startsWith("http://") && !lower.startsWith("https://")) {
            return Result.Fail("Enter a valid link that starts with http://, https:// or rtsp://")
        }
        val host = (Uri.parse(url).host ?: "").lowercase()
        if (siteHosts.any { host == it || host.endsWith(".$it") }) {
            return Result.Fail(
                "This is a page link from $host, not a direct video file, so it can't be streamed here.\n\n" +
                        "Tip: download the video first, then open it from Videos or Browse files. " +
                        "Links that end in .mp4, .mkv, .m3u8 or .mpd play directly."
            )
        }
        if (hasMediaExt(url)) return Result.Ok(url, guessMime(url))
        return try {
            probe(url, 0)
        } catch (e: UnknownHostException) {
            Result.Fail("Can't reach this address. Check the link and your internet connection.")
        } catch (e: SocketTimeoutException) {
            Result.Fail("The server took too long to answer. Try again later.")
        } catch (e: SSLException) {
            Result.Fail("A secure connection to this server could not be made.")
        } catch (e: Exception) {
            Result.Fail("Couldn't open this link. Check that it is correct and try again.")
        }
    }

    private fun probe(start: String, depth: Int): Result {
        var cur = start
        for (hop in 0..6) {
            val c = URL(cur).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 12000
            c.readTimeout = 12000
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept", "*/*")
            c.setRequestProperty("Range", "bytes=0-262143")
            try {
                val code = c.responseCode
                if (code in 300..399) {
                    val loc = c.getHeaderField("Location")
                        ?: return Result.Fail("The server redirected this link but gave no address.")
                    cur = URL(URL(cur), loc).toString()
                    continue
                }
                if (code >= 400) {
                    return Result.Fail(
                        "The server refused this link (error $code). It may have expired, need a login, or be blocked."
                    )
                }
                val ct = (c.contentType ?: "").lowercase()
                if (ct.startsWith("video/") || ct.startsWith("audio/")) return Result.Ok(cur, null)
                if (ct.contains("mpegurl")) return Result.Ok(cur, MimeTypes.APPLICATION_M3U8)
                if (ct.contains("dash+xml")) return Result.Ok(cur, MimeTypes.APPLICATION_MPD)
                val body = readUpTo(c.inputStream, 262144)
                val text = String(body, Charsets.UTF_8)
                val head = text.take(2048).trimStart()
                if (head.startsWith("#EXTM3U")) return Result.Ok(cur, MimeTypes.APPLICATION_M3U8)
                if (head.contains("<MPD")) return Result.Ok(cur, MimeTypes.APPLICATION_MPD)
                val isHtml = ct.contains("html") || head.lowercase().let { it.startsWith("<!doctype") || it.contains("<html") }
                if (!isHtml) return Result.Ok(cur, null)
                return fromPage(text, cur, depth)
            } finally {
                c.disconnect()
            }
        }
        return Result.Fail("This link redirects too many times.")
    }

    private fun readUpTo(ins: InputStream, max: Int): ByteArray {
        return ins.use {
            val out = java.io.ByteArrayOutputStream()
            val buf = ByteArray(8192)
            while (out.size() < max) {
                val n = it.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
            }
            out.toByteArray()
        }
    }

    private fun fromPage(htmlRaw: String, base: String, depth: Int): Result {
        val html = htmlRaw.replace("\\/", "/").replace("\\u0026", "&").replace("&amp;", "&")
        val found = LinkedHashSet<String>()
        val metaA = Regex("<meta[^>]+(?:property|name)=[\"'](?:og:video(?::secure_url|:url)?|twitter:player:stream)[\"'][^>]*content=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
        val metaB = Regex("<meta[^>]+content=[\"']([^\"']+)[\"'][^>]*(?:property|name)=[\"'](?:og:video(?::secure_url|:url)?|twitter:player:stream)[\"']", RegexOption.IGNORE_CASE)
        val tag = Regex("<(?:video|source)[^>]+src=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
        val any = Regex("https?://[^\"'\\s<>\\\\]+?\\.(?:m3u8|mp4|mpd|webm|mkv)(?:\\?[^\"'\\s<>\\\\]*)?", RegexOption.IGNORE_CASE)
        for (r in listOf(metaA, metaB, tag)) {
            r.findAll(html).forEach { m -> found.add(m.groupValues[1]) }
        }
        any.findAll(html).forEach { m -> found.add(m.value) }
        for (cand in found) {
            val abs = try { URL(URL(base), cand).toString() } catch (e: Exception) { continue }
            if (!abs.startsWith("http", ignoreCase = true)) continue
            if (hasMediaExt(abs)) return Result.Ok(abs, guessMime(abs))
            if (depth < 1) {
                val r = try { probe(abs, depth + 1) } catch (e: Exception) { null }
                if (r is Result.Ok) return r
            }
        }
        return Result.Fail(
            "This link opens a web page, and no playable video was found inside it.\n\n" +
                    "Use a direct link to a video file (.mp4, .mkv, .webm) or a stream (.m3u8, .mpd)."
        )
    }
}
