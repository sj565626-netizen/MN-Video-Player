package com.mn.videoplayer

import android.net.Uri

data class Video(
    val id: Long,
    val uri: Uri,
    val name: String,
    val duration: Long,
    val size: Long,
    val date: Long,
    val folder: String,
    val width: Int,
    val height: Int
)

data class HistoryEntry(val uri: String, val title: String, val time: Long, val duration: Long)

sealed class Row {
    data class Vid(val v: Video) : Row()
    data class Folder(val name: String, val count: Int, val total: Long) : Row()
    data class Action(val icon: Int, val title: String, val sub: String, val id: Int) : Row()
    data class Hist(val h: HistoryEntry) : Row()
    data class Header(val text: String) : Row()
}

const val FAV_FOLDER = "★ Favorites"
