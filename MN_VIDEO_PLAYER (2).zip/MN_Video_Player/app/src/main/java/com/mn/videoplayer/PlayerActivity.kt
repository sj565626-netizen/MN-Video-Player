package com.mn.videoplayer

import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.media.AudioManager
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.provider.MediaStore
import android.provider.Settings
import android.util.Rational
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.media3.ui.SubtitleView
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class PlayerActivity : AppCompatActivity() {

    companion object {
        fun start(ctx: Context, uris: ArrayList<String>, titles: ArrayList<String>, index: Int, secure: Boolean = false) {
            var u: List<String> = uris
            var t: List<String> = titles
            var idx = index
            if (u.size > 300) {
                val from = max(0, index - 150)
                val to = min(u.size, index + 150)
                u = u.subList(from, to)
                t = t.subList(from, to)
                idx = index - from
            }
            val i = Intent(ctx, PlayerActivity::class.java)
            i.putStringArrayListExtra("uris", ArrayList(u))
            i.putStringArrayListExtra("titles", ArrayList(t))
            i.putExtra("index", idx)
            i.putExtra("secure", secure)
            ctx.startActivity(i)
        }
    }

    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var root: FrameLayout
    private lateinit var controls: FrameLayout
    private lateinit var audioOnlyView: View
    private lateinit var bufferBar: View
    private lateinit var errorView: TextView
    private lateinit var hud: View
    private lateinit var hudIcon: ImageView
    private lateinit var hudText: TextView
    private lateinit var seekFeedback: TextView
    private lateinit var zoomLabel: TextView
    private lateinit var tvTitle: TextView
    private lateinit var tvPos: TextView
    private lateinit var tvDur: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var btnPlay: ImageButton
    private lateinit var btnNext: ImageButton
    private lateinit var btnPrev: ImageButton
    private lateinit var btnLoop: ImageButton
    private lateinit var btnMute: ImageButton
    private lateinit var btnSpeed: TextView
    private lateinit var btnAB: TextView
    private lateinit var btnUnlock: ImageButton
    private lateinit var btnSub: ImageButton
    private lateinit var audioMgr: AudioManager

    private val ui = Handler(Looper.getMainLooper())
    private var uris = ArrayList<String>()
    private var titles = ArrayList<String>()
    private val extraSubs = HashMap<String, MutableList<MediaItem.SubtitleConfiguration>>()

    private var controlsOn = true
    private var locked = false
    private var seeking = false
    private var muted = false
    private var audioOnly = false
    private var zoom = 1f
    private var scaling = false
    private var aspectIdx = 0
    private var orientIdx = 0
    private var abA = -1L
    private var abB = -1L
    private var sleepAt = 0L
    private var sleepEnd = false
    private var lastSaved = 0L
    private var historyUri = ""
    private var longSpeed = false
    private var speedBefore = 1f
    private var gMode = 0
    private var gStartPos = 0L
    private var gSeekTarget = 0L
    private var volAccum = 0f
    private var brightness = -1f
    private var eq: Equalizer? = null
    private var enhancer: LoudnessEnhancer? = null
    private var serviceOn = false
    private var inPip = false
    private var secure = false

    private lateinit var gd: GestureDetector
    private lateinit var sd: ScaleGestureDetector

    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH,
        AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
    )
    private val resizeNames = arrayOf("Fit", "Stretch", "Zoom (crop)", "Fixed width", "Fixed height")
    private val orientNames = arrayOf("Auto (follow video)", "Landscape", "Portrait", "Free rotation", "Locked")
    private val speeds = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 2.5f, 3f, 4f)

    private val subPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) addSubtitle(uri)
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
        applyBgService()
    }

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            ui.postDelayed(this, 250)
        }
    }
    private val hideRunnable = Runnable { hideControls() }
    private val hideHud = Runnable {
        hud.visibility = View.GONE
        seekFeedback.visibility = View.GONE
    }
    private val hideZoom = Runnable { zoomLabel.visibility = View.GONE }
    private val hideUnlock = Runnable { btnUnlock.visibility = View.GONE }

    // ------------------------------------------------------------------ lifecycle

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        setContentView(R.layout.activity_player)
        audioMgr = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        root = findViewById(R.id.root)
        controls = findViewById(R.id.controls)
        playerView = findViewById(R.id.playerView)
        audioOnlyView = findViewById(R.id.audioOnly)
        bufferBar = findViewById(R.id.bufferBar)
        errorView = findViewById(R.id.errorView)
        hud = findViewById(R.id.hud)
        hudIcon = findViewById(R.id.hudIcon)
        hudText = findViewById(R.id.hudText)
        seekFeedback = findViewById(R.id.seekFeedback)
        zoomLabel = findViewById(R.id.zoomLabel)
        tvTitle = findViewById(R.id.tvTitle)
        tvPos = findViewById(R.id.tvPos)
        tvDur = findViewById(R.id.tvDur)
        seekBar = findViewById(R.id.seekBar)
        btnPlay = findViewById(R.id.btnPlay)
        btnNext = findViewById(R.id.btnNext)
        btnPrev = findViewById(R.id.btnPrev)
        btnLoop = findViewById(R.id.btnLoop)
        btnMute = findViewById(R.id.btnMute)
        btnSpeed = findViewById(R.id.btnSpeed)
        btnAB = findViewById(R.id.btnAB)
        btnUnlock = findViewById(R.id.btnUnlock)
        btnSub = findViewById(R.id.btnSub)
        tvTitle.isSelected = true

        setupWindow()
        setupPlayer()
        setupButtons()
        setupGestures()
        applySubtitleStyle()
        tintBtn(btnLoop, false)
        if (Prefs.defaultSpeed != 1f) setSpeed(Prefs.defaultSpeed)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (locked) {
                    Toast.makeText(this@PlayerActivity, "Screen is locked. Tap the lock to unlock.", Toast.LENGTH_SHORT).show()
                } else {
                    finish()
                }
            }
        })

        handleIntent(intent)
        ui.post(ticker)
        showControls()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Prefs.autoPip && player.isPlaying && !locked && !audioOnly) enterPip()
    }

    override fun onPause() {
        super.onPause()
        savePos()
    }

    override fun onStop() {
        super.onStop()
        if (!Prefs.bgPlay) player.pause()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        savePos()
        stopBgService()
        releaseFx()
        player.release()
        super.onDestroy()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        controls.visibility = if (isInPictureInPictureMode) View.GONE else View.VISIBLE
        if (!isInPictureInPictureMode) showControls()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                togglePlay(); return true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                seekBy(Prefs.seekStep * 1000L); return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                seekBy(-Prefs.seekStep * 1000L); return true
            }
            KeyEvent.KEYCODE_MEDIA_NEXT -> {
                goNext(); return true
            }
            KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                goPrev(); return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ------------------------------------------------------------------ setup

    private fun setupWindow() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            controls.setPadding(i.left, i.top, i.right, i.bottom)
            insets
        }
        hideSystemBars()
        val lp = window.attributes
        brightness = lp.screenBrightness
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun setupPlayer() {
        val rf = DefaultRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)
        val attrs = androidx.media3.common.AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(StreamResolver.UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(20000)
        val dataSources = DefaultDataSource.Factory(this, http)
        player = ExoPlayer.Builder(this, rf)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSources))
            .setAudioAttributes(attrs, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .setSeekBackIncrementMs(Prefs.seekStep * 1000L)
            .setSeekForwardIncrementMs(Prefs.seekStep * 1000L)
            .build()
        player.pauseAtEndOfMediaItems = !Prefs.autoNext
        playerView.player = player
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                bufferBar.visibility = if (state == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
                if (state == Player.STATE_READY) {
                    errorView.visibility = View.GONE
                    onReady()
                }
                if (state == Player.STATE_ENDED) {
                    clearPos()
                    if (sleepEnd) {
                        sleepEnd = false
                        finish()
                    } else {
                        showControls(false)
                    }
                }
                updatePlayIcon()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updatePlayIcon()
                if (isPlaying) {
                    scheduleHide()
                    if (Prefs.bgPlay) startBgService()
                } else {
                    ui.removeCallbacks(hideRunnable)
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                tvTitle.text = mediaItem?.mediaMetadata?.title ?: ""
                abA = -1; abB = -1; updateAB()
                updateNavButtons()
                if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT) historyUri = ""
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                applyAutoOrientation(videoSize)
            }

            override fun onTracksChanged(tracks: Tracks) {
                val hasText = tracks.groups.any { it.type == C.TRACK_TYPE_TEXT }
                btnSub.alpha = if (hasText) 1f else 0.55f
            }

            override fun onPlayerError(error: PlaybackException) {
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition()
                    player.prepare()
                    return
                }
                bufferBar.visibility = View.GONE
                errorView.text = friendlyError(error)
                errorView.visibility = View.VISIBLE
                errorView.setOnClickListener {
                    errorView.visibility = View.GONE
                    player.prepare()
                    player.play()
                }
                showControls(false)
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                setupFx(audioSessionId)
            }
        })
        setupFx(player.audioSessionId)
    }

    private fun friendlyError(e: PlaybackException): String {
        val u = curUri()
        val net = u.startsWith("http") || u.startsWith("rtsp")
        val msg = when (e.errorCode) {
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
            PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED,
            PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED ->
                if (net) "This link is not a playable video.\nIt may be a web page or a protected stream. Use a direct video link (.mp4, .m3u8, .mpd)."
                else "This video's format isn't supported, or the file is damaged."
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
                "Couldn't connect.\nCheck your internet connection."
            PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ->
                "The server refused this link.\nIt may have expired or need a login."
            PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND ->
                "File not found.\nIt may have been moved or deleted."
            PlaybackException.ERROR_CODE_IO_NO_PERMISSION ->
                "No permission to open this file."
            PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED ->
                "This device can't play this video format."
            else -> "Something went wrong while playing."
        }
        return "$msg\n\nTap here to try again\n(${e.errorCodeName})"
    }

    private fun setupButtons() {
        findViewById<View>(R.id.btnBack).setOnClickListener { if (!locked) finish() }
        btnPlay.setOnClickListener { togglePlay() }
        btnNext.setOnClickListener { goNext() }
        btnPrev.setOnClickListener { goPrev() }
        findViewById<View>(R.id.btnRew).setOnClickListener { seekBy(-Prefs.seekStep * 1000L); scheduleHide() }
        findViewById<View>(R.id.btnFwd).setOnClickListener { seekBy(Prefs.seekStep * 1000L); scheduleHide() }
        findViewById<View>(R.id.btnLock).setOnClickListener { setLocked(true) }
        btnUnlock.setOnClickListener { setLocked(false) }
        findViewById<View>(R.id.btnRotate).setOnClickListener { cycleOrientation() }
        findViewById<View>(R.id.btnAspect).setOnClickListener { cycleAspect() }
        btnSpeed.setOnClickListener { showSpeedDialog() }
        btnAB.setOnClickListener { cycleAB() }
        btnLoop.setOnClickListener { cycleLoop() }
        btnMute.setOnClickListener { toggleMute() }
        findViewById<View>(R.id.btnPip).setOnClickListener { enterPip() }
        btnSub.setOnClickListener { showSubtitleMenu() }
        findViewById<View>(R.id.btnAudio).setOnClickListener { showTrackMenu(C.TRACK_TYPE_AUDIO, "Audio track") }
        findViewById<View>(R.id.btnShot).setOnClickListener { takeScreenshot() }
        findViewById<View>(R.id.btnMore).setOnClickListener { showMoreMenu() }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    tvPos.text = U.time(progress.toLong())
                    player.seekTo(progress.toLong())
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {
                seeking = true
                ui.removeCallbacks(hideRunnable)
            }

            override fun onStopTrackingTouch(s: SeekBar?) {
                seeking = false
                scheduleHide()
            }
        })
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupGestures() {
        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                gMode = 0
                gStartPos = player.currentPosition
                volAccum = audioMgr.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (controlsOn) hideControls() else showControls()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val w = root.width
                val step = Prefs.seekStep * 1000L
                if (!Prefs.gestures) {
                    togglePlay()
                } else if (e.x < w / 3f) {
                    seekBy(-step)
                    showSeekFeedback("« ${Prefs.seekStep}s", Gravity.START)
                } else if (e.x > w * 2 / 3f) {
                    seekBy(step)
                    showSeekFeedback("${Prefs.seekStep}s »", Gravity.END)
                } else {
                    togglePlay()
                }
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (!Prefs.gestures || e1 == null || scaling) return false
                if (gMode == 0) {
                    gMode = if (abs(dx) > abs(dy)) 1 else if (e1.x < root.width / 2f) 2 else 3
                    if (gMode == 1) hideControls()
                }
                when (gMode) {
                    1 -> {
                        val dur = player.duration
                        if (dur <= 0) return true
                        val delta = ((e2.x - e1.x) / root.width * 120000f).toLong()
                        gSeekTarget = (gStartPos + delta).coerceIn(0L, dur)
                        val d = (gSeekTarget - gStartPos) / 1000
                        val sign = if (d >= 0) "+" else "-"
                        showHud(if (d >= 0) R.drawable.ic_forward else R.drawable.ic_rewind,
                            "$sign${abs(d)}s  [${U.time(gSeekTarget)}]", false)
                    }
                    2 -> {
                        adjustBrightness(dy / root.height * 1.3f)
                    }
                    3 -> {
                        val maxV = audioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        volAccum = (volAccum + dy / root.height * maxV * 1.4f).coerceIn(0f, maxV.toFloat())
                        audioMgr.setStreamVolume(AudioManager.STREAM_MUSIC, volAccum.toInt(), 0)
                        val pct = (volAccum / maxV * 100).toInt()
                        showHud(if (pct == 0) R.drawable.ic_volume_off else R.drawable.ic_volume_up, "$pct%", true)
                    }
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (Prefs.gestures && player.isPlaying && !scaling) {
                    longSpeed = true
                    speedBefore = player.playbackParameters.speed
                    player.playbackParameters = PlaybackParameters(2f)
                    showHud(R.drawable.ic_forward, "2x speed", false)
                }
            }
        })
        sd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(d: ScaleGestureDetector): Boolean {
                scaling = true
                return true
            }

            override fun onScale(d: ScaleGestureDetector): Boolean {
                zoom = (zoom * d.scaleFactor).coerceIn(1f, 4f)
                applyZoom()
                return true
            }

            override fun onScaleEnd(d: ScaleGestureDetector) {
                scaling = false
                ui.removeCallbacks(hideZoom)
                ui.postDelayed(hideZoom, 900)
            }
        })
        root.setOnTouchListener { _, ev ->
            if (locked) {
                if (ev.actionMasked == MotionEvent.ACTION_UP) showUnlockTemp()
                return@setOnTouchListener true
            }
            if (Prefs.gestures) sd.onTouchEvent(ev)
            if (!sd.isInProgress) gd.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) endGesture()
            true
        }
    }

    private fun endGesture() {
        if (gMode == 1) {
            player.seekTo(gSeekTarget)
        }
        if (longSpeed) {
            longSpeed = false
            player.playbackParameters = PlaybackParameters(speedBefore)
        }
        gMode = 0
        ui.removeCallbacks(hideHud)
        ui.postDelayed(hideHud, 700)
    }

    // ------------------------------------------------------------------ playlist

    private fun handleIntent(i: Intent) {
        secure = i.getBooleanExtra("secure", false)
        if (secure) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        val ul = i.getStringArrayListExtra("uris")
        if (ul != null && ul.isNotEmpty()) {
            uris = ul
            titles = i.getStringArrayListExtra("titles") ?: ArrayList()
            while (titles.size < uris.size) titles.add(U.nameOf(this, Uri.parse(uris[titles.size])))
            loadPlaylist(i.getIntExtra("index", 0).coerceIn(0, uris.size - 1), true)
        } else {
            val d = i.data
            if (d != null) {
                uris = arrayListOf(d.toString())
                titles = arrayListOf(U.nameOf(this, d))
                loadPlaylist(0, true)
            } else if (uris.isEmpty()) {
                finish()
            }
        }
    }

    private fun buildItem(i: Int): MediaItem {
        val u = uris[i]
        val b = MediaItem.Builder()
            .setUri(Uri.parse(u))
            .setMediaMetadata(MediaMetadata.Builder().setTitle(titles.getOrElse(i) { "" }).build())
        (StreamHints.mime[u] ?: StreamResolver.guessMime(u))?.let { b.setMimeType(it) }
        extraSubs[u]?.let { b.setSubtitleConfigurations(it) }
        return b.build()
    }

    private fun loadPlaylist(index: Int, useResume: Boolean) {
        val items = uris.indices.map { buildItem(it) }
        var pos = 0L
        if (useResume && Prefs.resume) {
            val p = Prefs.getPos(uris[index])
            if (p > 3000) {
                pos = p
                Toast.makeText(this, "Resumed from ${U.time(p)}", Toast.LENGTH_SHORT).show()
            }
        }
        player.setMediaItems(items, index, pos)
        player.prepare()
        player.playWhenReady = true
        tvTitle.text = titles.getOrElse(index) { "" }
        updateNavButtons()
    }

    private fun updateNavButtons() {
        btnNext.alpha = if (player.hasNextMediaItem()) 1f else 0.4f
        btnPrev.alpha = if (player.hasPreviousMediaItem() || player.currentPosition > 3000) 1f else 0.4f
    }

    private fun curUri(): String {
        val i = player.currentMediaItemIndex
        return if (i in uris.indices) uris[i] else ""
    }

    private fun onReady() {
        val dur = player.duration
        tvDur.text = if (dur > 0) U.time(dur) else "LIVE"
        val u = curUri()
        if (u.isNotEmpty() && u != historyUri) {
            historyUri = u
            if (!secure) Prefs.addHistory(u, titles.getOrElse(player.currentMediaItemIndex) { "Video" }, max(dur, 0L))
        }
        updateNavButtons()
        applySubtitleStyle()
    }

    private fun savePos() {
        if (!::player.isInitialized) return
        val u = curUri()
        if (u.isEmpty()) return
        var pos = player.currentPosition
        val dur = player.duration
        if (dur > 0 && pos > dur - 4000) pos = 0
        if (pos < 3000) pos = 0
        Prefs.setPos(u, pos)
    }

    private fun clearPos() {
        val u = curUri()
        if (u.isNotEmpty()) Prefs.setPos(u, 0)
    }

    // ------------------------------------------------------------------ playback controls

    private fun togglePlay() {
        if (player.playbackState == Player.STATE_ENDED) {
            player.seekTo(0)
            player.play()
        } else if (player.isPlaying) {
            player.pause()
        } else {
            player.play()
        }
    }

    private fun seekBy(ms: Long) {
        val dur = player.duration
        var t = player.currentPosition + ms
        t = if (dur > 0) t.coerceIn(0L, dur) else max(0L, t)
        player.seekTo(t)
        tick()
    }

    private fun goNext() {
        if (player.hasNextMediaItem()) {
            player.seekToNextMediaItem()
        } else {
            Toast.makeText(this, "This is the last video", Toast.LENGTH_SHORT).show()
        }
        scheduleHide()
    }

    private fun goPrev() {
        if (player.currentPosition > 3000 || !player.hasPreviousMediaItem()) {
            player.seekTo(0)
        } else {
            player.seekToPreviousMediaItem()
        }
        scheduleHide()
    }

    private fun updatePlayIcon() {
        val showPause = player.isPlaying || (player.playWhenReady && player.playbackState == Player.STATE_BUFFERING)
        btnPlay.setImageResource(if (showPause) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun tick() {
        if (!::player.isInitialized) return
        val dur = player.duration
        val pos = player.currentPosition
        if (!seeking) {
            if (dur > 0) {
                if (seekBar.max != dur.toInt()) seekBar.max = dur.toInt()
                seekBar.progress = pos.toInt()
                seekBar.secondaryProgress = player.bufferedPosition.toInt()
                tvDur.text = U.time(dur)
            } else {
                seekBar.progress = 0
                tvDur.text = "LIVE"
            }
            tvPos.text = U.time(pos)
        }
        if (abA >= 0 && abB > abA && pos >= abB) player.seekTo(abA)
        if (sleepAt > 0 && SystemClock.elapsedRealtime() >= sleepAt) {
            sleepAt = 0
            player.pause()
            Toast.makeText(this, "Sleep timer ended", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (player.isPlaying && now - lastSaved > 5000) {
            lastSaved = now
            savePos()
        }
        updateNavButtons()
    }

    // ------------------------------------------------------------------ controls visibility

    private fun showControls(autoHide: Boolean = true) {
        if (locked) return
        controlsOn = true
        controls.visibility = if (inPip) View.GONE else View.VISIBLE
        controls.animate().alpha(1f).setDuration(150).start()
        if (autoHide) scheduleHide()
    }

    private fun hideControls() {
        if (locked || seeking) return
        if (!player.isPlaying) return
        controlsOn = false
        controls.animate().alpha(0f).setDuration(200).withEndAction {
            if (!controlsOn) controls.visibility = View.GONE
        }.start()
    }

    private fun scheduleHide() {
        ui.removeCallbacks(hideRunnable)
        if (player.isPlaying) ui.postDelayed(hideRunnable, 4000)
    }

    private fun setLocked(v: Boolean) {
        locked = v
        if (v) {
            controlsOn = false
            controls.visibility = View.GONE
            showUnlockTemp()
        } else {
            btnUnlock.visibility = View.GONE
            controls.alpha = 1f
            showControls()
        }
    }

    private fun showUnlockTemp() {
        btnUnlock.visibility = View.VISIBLE
        ui.removeCallbacks(hideUnlock)
        ui.postDelayed(hideUnlock, 2500)
    }

    // ------------------------------------------------------------------ HUD / gestures helpers

    private fun showHud(icon: Int, text: String, withBar: Boolean) {
        hudIcon.setImageResource(icon)
        hudText.text = text
        hud.visibility = View.VISIBLE
        ui.removeCallbacks(hideHud)
    }

    private fun showSeekFeedback(text: String, g: Int) {
        val lp = seekFeedback.layoutParams as FrameLayout.LayoutParams
        lp.gravity = android.view.Gravity.CENTER_VERTICAL or (if (g == Gravity.START) android.view.Gravity.START else android.view.Gravity.END)
        lp.marginStart = if (g == Gravity.START) U.dp(this, 64) else 0
        lp.marginEnd = if (g == Gravity.END) U.dp(this, 64) else 0
        seekFeedback.layoutParams = lp
        seekFeedback.text = text
        seekFeedback.visibility = View.VISIBLE
        ui.removeCallbacks(hideHud)
        ui.postDelayed(hideHud, 600)
    }

    private object Gravity {
        const val START = 0
        const val END = 1
    }

    private fun adjustBrightness(delta: Float) {
        val lp = window.attributes
        var b = lp.screenBrightness
        if (b < 0) {
            b = try {
                Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
            } catch (_: Exception) {
                0.5f
            }
        }
        b = (b + delta).coerceIn(0.02f, 1f)
        lp.screenBrightness = b
        window.attributes = lp
        showHud(R.drawable.ic_brightness, "${(b * 100).toInt()}%", true)
    }

    private fun applyZoom() {
        playerView.scaleX = zoom
        playerView.scaleY = zoom
        zoomLabel.text = "Zoom ${(zoom * 100).toInt()}%"
        zoomLabel.visibility = View.VISIBLE
        ui.removeCallbacks(hideZoom)
    }

    private fun resetZoom() {
        zoom = 1f
        playerView.scaleX = 1f
        playerView.scaleY = 1f
    }

    private fun tintBtn(b: ImageButton, on: Boolean) {
        b.imageTintList = ColorStateList.valueOf(if (on) getColor(R.color.accent) else Color.WHITE)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ tool buttons

    private fun cycleAspect() {
        aspectIdx = (aspectIdx + 1) % resizeModes.size
        playerView.resizeMode = resizeModes[aspectIdx]
        resetZoom()
        toast("Aspect: ${resizeNames[aspectIdx]}")
        scheduleHide()
    }

    private fun applyOrientation() {
        requestedOrientation = when (orientIdx) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            3 -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            4 -> ActivityInfo.SCREEN_ORIENTATION_LOCKED
            else -> {
                val vs = player.videoSize
                if (vs.width > 0 && vs.height > 0 && Prefs.autoRotate) {
                    if (vs.width >= vs.height) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                } else ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            }
        }
    }

    private fun applyAutoOrientation(vs: VideoSize) {
        if (orientIdx == 0 && Prefs.autoRotate && vs.width > 0 && vs.height > 0 && !inPip) applyOrientation()
        val sub = playerView.subtitleView
        sub?.setBottomPaddingFraction(SubtitleView.DEFAULT_BOTTOM_PADDING_FRACTION)
    }

    private fun cycleOrientation() {
        orientIdx = (orientIdx + 1) % orientNames.size
        applyOrientation()
        toast("Orientation: ${orientNames[orientIdx]}")
        scheduleHide()
    }

    private fun showSpeedDialog() {
        val cur = player.playbackParameters.speed
        val labels = speeds.map { fmtSpeed(it) }.toTypedArray()
        var sel = speeds.indexOfFirst { abs(it - cur) < 0.01f }
        if (sel < 0) sel = 3
        AlertDialog.Builder(this).setTitle("Playback speed")
            .setSingleChoiceItems(labels, sel) { d, i ->
                setSpeed(speeds[i])
                d.dismiss()
            }.show()
    }

    private fun fmtSpeed(s: Float): String =
        (if (s == s.toInt().toFloat()) s.toInt().toString() else String.format(Locale.US, "%.2f", s).trimEnd('0')) + "x"

    private fun setSpeed(s: Float) {
        player.playbackParameters = PlaybackParameters(s)
        btnSpeed.text = fmtSpeed(s)
        btnSpeed.setTextColor(if (s != 1f) getColor(R.color.accent) else Color.WHITE)
    }

    private fun cycleAB() {
        val pos = player.currentPosition
        when {
            abA < 0 -> {
                abA = pos; toast("Point A set: ${U.time(pos)}")
            }
            abB < 0 -> {
                if (pos <= abA + 500) {
                    toast("Point B must be after A")
                } else {
                    abB = pos; toast("Repeating A–B: ${U.time(abA)} → ${U.time(abB)}")
                }
            }
            else -> {
                abA = -1; abB = -1; toast("A–B repeat off")
            }
        }
        updateAB()
    }

    private fun updateAB() {
        btnAB.text = when {
            abA < 0 -> "A-B"
            abB < 0 -> "A-"
            else -> "A-B"
        }
        btnAB.setTextColor(if (abA >= 0) getColor(R.color.accent) else Color.WHITE)
    }

    private fun cycleLoop() {
        when (player.repeatMode) {
            Player.REPEAT_MODE_OFF -> {
                player.repeatMode = Player.REPEAT_MODE_ONE
                btnLoop.setImageResource(R.drawable.ic_loop_one)
                tintBtn(btnLoop, true)
                toast("Repeat: this video")
            }
            Player.REPEAT_MODE_ONE -> {
                player.repeatMode = Player.REPEAT_MODE_ALL
                btnLoop.setImageResource(R.drawable.ic_loop)
                tintBtn(btnLoop, true)
                toast("Repeat: all videos")
            }
            else -> {
                player.repeatMode = Player.REPEAT_MODE_OFF
                btnLoop.setImageResource(R.drawable.ic_loop)
                tintBtn(btnLoop, false)
                toast("Repeat: off")
            }
        }
    }

    private fun toggleMute() {
        muted = !muted
        player.volume = if (muted) 0f else 1f
        btnMute.setImageResource(if (muted) R.drawable.ic_volume_off else R.drawable.ic_volume_up)
        tintBtn(btnMute, muted)
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26 || !packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            toast("Picture-in-picture is not supported on this device")
            return
        }
        val vs = player.videoSize
        var w = if (vs.width > 0) vs.width else 16
        var h = if (vs.height > 0) vs.height else 9
        val ratio = w.toFloat() / h
        if (ratio > 2.39f) { w = 239; h = 100 } else if (ratio < 0.42f) { w = 42; h = 100 }
        try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(w, h)).build())
        } catch (e: Exception) {
            toast("Could not enter picture-in-picture")
        }
    }

    // ------------------------------------------------------------------ tracks / subtitles

    private fun describe(f: Format, type: Int, n: Int): String {
        val parts = ArrayList<String>()
        val lbl: String = f.label ?: ""
        val lang: String = f.language ?: ""
        val name: String = when {
            lbl.isNotEmpty() -> lbl
            lang.isNotEmpty() && lang != "und" -> Locale.forLanguageTag(lang).displayLanguage
            type == C.TRACK_TYPE_VIDEO -> "Video $n"
            else -> "Track $n"
        }
        parts.add(name)
        when (type) {
            C.TRACK_TYPE_AUDIO -> {
                if (f.channelCount > 0) {
                    val ch = when (f.channelCount) {
                        1 -> "Mono"
                        2 -> "Stereo"
                        6 -> "5.1"
                        8 -> "7.1"
                        else -> "${f.channelCount}ch"
                    }
                    parts.add(ch)
                }
                f.sampleMimeType?.substringAfter('/')?.uppercase()?.let { parts.add(it) }
            }
            C.TRACK_TYPE_VIDEO -> {
                if (f.height > 0) parts.add("${f.height}p")
                if (f.bitrate > 0) parts.add(String.format(Locale.US, "%.1f Mbps", f.bitrate / 1_000_000f))
            }
        }
        return parts.joinToString(" · ")
    }

    private class TI(val group: Tracks.Group, val idx: Int)

    private fun collect(type: Int, labels: ArrayList<String>): ArrayList<TI> {
        val out = ArrayList<TI>()
        for (g in player.currentTracks.groups) {
            if (g.type != type) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                out.add(TI(g, i))
                labels.add(describe(g.getTrackFormat(i), type, labels.size + 1))
            }
        }
        return out
    }

    private fun selectTrack(type: Int, t: TI?) {
        val b = player.trackSelectionParameters.buildUpon()
        b.clearOverridesOfType(type)
        if (t == null) {
            b.setTrackTypeDisabled(type, true)
        } else {
            b.setTrackTypeDisabled(type, false)
            b.setOverrideForType(TrackSelectionOverride(t.group.mediaTrackGroup, listOf(t.idx)))
        }
        player.trackSelectionParameters = b.build()
    }

    private fun showTrackMenu(type: Int, title: String) {
        val labels = ArrayList<String>()
        val tis = collect(type, labels)
        if (tis.isEmpty()) {
            toast("No $title available")
            return
        }
        val disabled = player.trackSelectionParameters.disabledTrackTypes.contains(type)
        val items = ArrayList<String>()
        if (type == C.TRACK_TYPE_VIDEO) items.add("Auto")
        items.addAll(labels)
        val off = if (type == C.TRACK_TYPE_TEXT) 1 else 0
        if (off == 1) items.add(0, "Off")
        val selFlags = tis.map { it.group.isTrackSelected(it.idx) }
        val shown = items.mapIndexed { n, s ->
            val on = when {
                type == C.TRACK_TYPE_TEXT && n == 0 -> disabled || selFlags.none { it }
                type == C.TRACK_TYPE_VIDEO && n == 0 -> player.trackSelectionParameters.overrides.none { it.key.type == C.TRACK_TYPE_VIDEO }
                else -> {
                    val k = n - (if (type == C.TRACK_TYPE_VIDEO) 1 else 0) - off
                    k in selFlags.indices && selFlags[k] && !disabled
                }
            }
            (if (on) "●  " else "○  ") + s
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle(title).setItems(shown) { _, n ->
            when {
                type == C.TRACK_TYPE_TEXT && n == 0 -> selectTrack(type, null)
                type == C.TRACK_TYPE_VIDEO && n == 0 -> {
                    val b = player.trackSelectionParameters.buildUpon()
                    b.clearOverridesOfType(C.TRACK_TYPE_VIDEO).setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, audioOnly)
                    player.trackSelectionParameters = b.build()
                }
                else -> {
                    val k = n - (if (type == C.TRACK_TYPE_VIDEO) 1 else 0) - off
                    selectTrack(type, tis[k])
                }
            }
        }.show()
    }

    private fun showSubtitleMenu() {
        Ui.menu(
            this, "Subtitles", listOf(
                Entry(R.drawable.ic_cc, "Subtitle tracks", "Choose a track or turn subtitles off") {
                    showTrackMenu(C.TRACK_TYPE_TEXT, "Subtitle tracks")
                },
                Entry(R.drawable.ic_add, "Add subtitle file", "SRT, VTT, ASS or TTML") {
                    subPicker.launch(arrayOf("*/*"))
                },
                Entry(R.drawable.ic_textsize, "Subtitle size", "${Prefs.subSize}% - tap to change") {
                    val sizes = intArrayOf(70, 85, 100, 125, 150, 200)
                    val k = sizes.indexOf(Prefs.subSize)
                    Prefs.subSize = sizes[(k + 1) % sizes.size]
                    applySubtitleStyle()
                    showSubtitleMenu()
                },
                Entry(R.drawable.ic_palette, "Subtitle color") {
                    val names = arrayOf("White", "Yellow", "Cyan", "Green")
                    val cols = intArrayOf(Color.WHITE, Color.YELLOW, Color.CYAN, Color.GREEN)
                    AlertDialog.Builder(this).setTitle("Subtitle color").setItems(names) { _, c ->
                        Prefs.subColor = cols[c]
                        applySubtitleStyle()
                    }.show()
                }
            )
        )
    }

    private fun applySubtitleStyle() {
        val sv = playerView.subtitleView ?: return
        sv.setApplyEmbeddedStyles(false)
        sv.setApplyEmbeddedFontSizes(false)
        sv.setFractionalTextSize(SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * Prefs.subSize / 100f)
        sv.setStyle(CaptionStyleCompat(Prefs.subColor, Color.TRANSPARENT, Color.TRANSPARENT,
            CaptionStyleCompat.EDGE_TYPE_OUTLINE, Color.BLACK, null))
    }

    private fun addSubtitle(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        val name = U.nameOf(this, uri)
        val ext = name.substringAfterLast('.', "").lowercase()
        val mime = when (ext) {
            "vtt" -> MimeTypes.TEXT_VTT
            "ass", "ssa" -> MimeTypes.TEXT_SSA
            "ttml", "xml", "dfxp" -> MimeTypes.APPLICATION_TTML
            "srt" -> MimeTypes.APPLICATION_SUBRIP
            else -> {
                toast("Unsupported subtitle file. Use SRT, VTT, ASS or TTML.")
                return
            }
        }
        val cfg = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mime)
            .setLabel(name)
            .setLanguage("und")
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        val u = curUri()
        extraSubs.getOrPut(u) { ArrayList() }.add(cfg)
        val idx = player.currentMediaItemIndex
        val pos = player.currentPosition
        val wasPlaying = player.playWhenReady
        val b = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
        player.trackSelectionParameters = b.build()
        player.setMediaItems(uris.indices.map { buildItem(it) }, idx, pos)
        player.prepare()
        player.playWhenReady = wasPlaying
        toast("Subtitle added: $name")
    }

    // ------------------------------------------------------------------ more menu

    private fun showMoreMenu() {
        val e = ArrayList<Entry>()
        if (uris.size > 1) {
            e.add(Entry(R.drawable.ic_list, "Playlist", "${uris.size} videos") { showPlaylist() })
            e.add(Entry(R.drawable.ic_shuffle, "Shuffle", if (player.shuffleModeEnabled) "On" else "Off") { toggleShuffle() })
        }
        e.add(Entry(R.drawable.ic_clock, "Jump to time", "Go to an exact minute and second") { showGoTo() })
        e.add(Entry(R.drawable.ic_timer, "Sleep timer", if (sleepAt > 0 || sleepEnd) "On" else "Off") { showSleepDialog() })
        e.add(Entry(R.drawable.ic_equalizer, "Equalizer & volume boost") { showEqualizer() })
        e.add(Entry(R.drawable.ic_video, "Video quality / tracks") { showTrackMenu(C.TRACK_TYPE_VIDEO, "Video track") })
        e.add(Entry(R.drawable.ic_headphones, "Audio only mode", if (audioOnly) "On" else "Off") { toggleAudioOnly() })
        e.add(Entry(R.drawable.ic_audio, "Play in background", if (Prefs.bgPlay) "On" else "Off") { toggleBg() })
        e.add(Entry(R.drawable.ic_cc, "Subtitles") { showSubtitleMenu() })
        e.add(Entry(R.drawable.ic_info, "Video info") { showInfo() })
        if (!secure) e.add(Entry(R.drawable.ic_share, "Share") { shareCurrent() })
        Ui.menu(this, "More", e)
    }

    private fun toggleShuffle() {
        player.shuffleModeEnabled = !player.shuffleModeEnabled
        toast(if (player.shuffleModeEnabled) "Shuffle on" else "Shuffle off")
    }

    private fun parseTime(s: String): Long? {
        val parts = s.trim().split(":")
        if (parts.isEmpty() || parts.size > 3) return null
        var sec = 0L
        for (p in parts) {
            val n = p.trim().toLongOrNull() ?: return null
            if (n < 0) return null
            sec = sec * 60 + n
        }
        return sec * 1000L
    }

    private fun showGoTo() {
        val pad = U.dp(this, 22)
        val et = EditText(this)
        et.hint = "e.g. 1:30 or 01:02:03"
        et.inputType = InputType.TYPE_CLASS_TEXT
        et.setSingleLine(true)
        et.setTextColor(getColor(R.color.text))
        et.setHintTextColor(getColor(R.color.text2))
        val box = LinearLayout(this)
        box.setPadding(pad, U.dp(this, 8), pad, 0)
        box.addView(et, LinearLayout.LayoutParams(-1, -2))
        val dur = player.duration
        AlertDialog.Builder(this).setTitle("Jump to time")
            .setMessage("Now at ${U.time(player.currentPosition)}" + (if (dur > 0) " of ${U.time(dur)}" else ""))
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Go") { _, _ ->
                val t = parseTime(et.text.toString())
                if (t == null) {
                    toast("Type the time like 1:30 or 01:02:03")
                } else {
                    player.seekTo(if (dur > 0) t.coerceIn(0L, dur) else t)
                }
            }.show()
    }

    private fun showPlaylist() {
        val cur = player.currentMediaItemIndex
        val items = titles.mapIndexed { i, t -> (if (i == cur) "▶  " else "     ") + t }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Playlist").setItems(items) { _, i ->
            player.seekTo(i, 0)
            player.play()
        }.show()
    }

    private fun showSleepDialog() {
        val labels = arrayOf("Off", "15 minutes", "30 minutes", "45 minutes", "60 minutes", "90 minutes", "End of video")
        val mins = intArrayOf(0, 15, 30, 45, 60, 90, -1)
        AlertDialog.Builder(this).setTitle("Sleep timer").setItems(labels) { _, i ->
            sleepAt = 0
            sleepEnd = false
            player.pauseAtEndOfMediaItems = !Prefs.autoNext
            when {
                mins[i] > 0 -> {
                    sleepAt = SystemClock.elapsedRealtime() + mins[i] * 60_000L
                    toast("Sleep timer set for ${mins[i]} minutes")
                }
                mins[i] < 0 -> {
                    sleepEnd = true
                    player.pauseAtEndOfMediaItems = true
                    toast("Player will close when this video ends")
                }
                else -> toast("Sleep timer off")
            }
        }.show()
    }

    private fun toggleAudioOnly() {
        audioOnly = !audioOnly
        val b = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, audioOnly)
        player.trackSelectionParameters = b.build()
        audioOnlyView.visibility = if (audioOnly) View.VISIBLE else View.GONE
        toast(if (audioOnly) "Audio only mode on" else "Audio only mode off")
    }

    private fun toggleBg() {
        Prefs.bgPlay = !Prefs.bgPlay
        if (Prefs.bgPlay) {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                notifPerm.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            } else applyBgService()
            toast("Background play on")
        } else {
            stopBgService()
            toast("Background play off")
        }
    }

    private fun applyBgService() {
        if (Prefs.bgPlay && player.isPlaying) startBgService()
    }

    private fun startBgService() {
        if (serviceOn) return
        try {
            val i = Intent(this, PlaybackService::class.java).putExtra("title", if (secure) "Private video" else tvTitle.text.toString())
            androidx.core.content.ContextCompat.startForegroundService(this, i)
            serviceOn = true
        } catch (_: Exception) {
        }
    }

    private fun stopBgService() {
        if (!serviceOn) return
        try {
            stopService(Intent(this, PlaybackService::class.java))
        } catch (_: Exception) {
        }
        serviceOn = false
    }

    private fun showInfo() {
        val sb = StringBuilder()
        val title = titles.getOrElse(player.currentMediaItemIndex) { "" }
        sb.append("Name: ").append(title).append('\n')
        sb.append("Duration: ").append(U.time(player.duration)).append('\n')
        val v = player.videoFormat
        if (v != null) {
            sb.append("\nVIDEO\n")
            sb.append("Resolution: ${v.width}×${v.height}\n")
            if (v.frameRate > 0) sb.append(String.format(Locale.US, "Frame rate: %.2f fps\n", v.frameRate))
            if (v.bitrate > 0) sb.append(String.format(Locale.US, "Bitrate: %.2f Mbps\n", v.bitrate / 1_000_000f))
            v.sampleMimeType?.let { sb.append("Codec: ${it.substringAfter('/')}\n") }
        }
        val a = player.audioFormat
        if (a != null) {
            sb.append("\nAUDIO\n")
            a.sampleMimeType?.let { sb.append("Codec: ${it.substringAfter('/')}\n") }
            if (a.channelCount > 0) sb.append("Channels: ${a.channelCount}\n")
            if (a.sampleRate > 0) sb.append("Sample rate: ${a.sampleRate} Hz\n")
            if (a.bitrate > 0) sb.append("Bitrate: ${a.bitrate / 1000} kbps\n")
        }
        val u = curUri()
        if (u.startsWith("content") || u.startsWith("file")) {
            try {
                contentResolver.openAssetFileDescriptor(Uri.parse(u), "r")?.use {
                    sb.append("\nFile size: ").append(U.size(it.length)).append('\n')
                }
            } catch (_: Exception) {
            }
        } else sb.append("\nSource: ").append(u).append('\n')
        AlertDialog.Builder(this).setTitle("Video info").setMessage(sb.toString()).setPositiveButton("OK", null).show()
    }

    private fun shareCurrent() {
        val u = curUri()
        if (u.isEmpty()) return
        val it = Intent(Intent.ACTION_SEND)
        if (u.startsWith("http") || u.startsWith("rtsp")) {
            it.type = "text/plain"
            it.putExtra(Intent.EXTRA_TEXT, u)
        } else {
            it.type = "video/*"
            it.putExtra(Intent.EXTRA_STREAM, Uri.parse(u))
            it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(it, "Share"))
    }

    // ------------------------------------------------------------------ screenshot

    private fun takeScreenshot() {
        val tv = playerView.videoSurfaceView as? TextureView
        val bmp = tv?.bitmap
        if (bmp == null || audioOnly) {
            toast("Screenshot is not available right now")
            return
        }
        val name = "MN_" + System.currentTimeMillis() + ".jpg"
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues()
                cv.put(MediaStore.Images.Media.DISPLAY_NAME, name)
                cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/MN Video Player")
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    ?: throw IllegalStateException("insert failed")
                contentResolver.openOutputStream(uri)?.use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 95, it) }
                toast("Screenshot saved to Pictures/MN Video Player")
            } else {
                val dir = getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES) ?: filesDir
                val f = File(dir, name)
                f.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 95, it) }
                toast("Screenshot saved: ${f.absolutePath}")
            }
        } catch (e: Exception) {
            toast("Could not save screenshot")
        }
    }

    // ------------------------------------------------------------------ equalizer

    private fun setupFx(sid: Int) {
        releaseFx()
        if (sid == C.AUDIO_SESSION_ID_UNSET || sid == 0) return
        try {
            val e = Equalizer(0, sid)
            val saved = Prefs.eqLevels.split(',').mapNotNull { it.toShortOrNull() }
            for (b in 0 until e.numberOfBands) {
                if (b < saved.size) e.setBandLevel(b.toShort(), saved[b])
            }
            e.enabled = Prefs.eqOn
            eq = e
        } catch (_: Exception) {
            eq = null
        }
        try {
            val l = LoudnessEnhancer(sid)
            l.setTargetGain(Prefs.boost * 15)
            l.enabled = Prefs.boost > 0
            enhancer = l
        } catch (_: Exception) {
            enhancer = null
        }
    }

    private fun releaseFx() {
        try { eq?.release() } catch (_: Exception) {}
        try { enhancer?.release() } catch (_: Exception) {}
        eq = null
        enhancer = null
    }

    private fun saveEq() {
        val e = eq ?: return
        val sb = StringBuilder()
        for (b in 0 until e.numberOfBands) {
            if (b > 0) sb.append(',')
            sb.append(e.getBandLevel(b.toShort()).toInt())
        }
        Prefs.eqLevels = sb.toString()
    }

    private fun label(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(getColor(R.color.text))
        t.textSize = 14f
        return t
    }

    private fun showEqualizer() {
        val e = eq
        if (e == null) {
            toast("Equalizer is not available on this device")
            return
        }
        val pad = U.dp(this, 20)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, U.dp(this, 8), pad, U.dp(this, 8))

        val sw = androidx.appcompat.widget.SwitchCompat(this)
        sw.text = "Enable equalizer"
        sw.setTextColor(getColor(R.color.text))
        sw.isChecked = Prefs.eqOn
        sw.setOnCheckedChangeListener { _, on ->
            Prefs.eqOn = on
            try { e.enabled = on } catch (_: Exception) {}
        }
        box.addView(sw)

        val range = e.bandLevelRange
        val minL = range[0].toInt()
        val maxL = range[1].toInt()
        val bars = ArrayList<SeekBar>()
        for (b in 0 until e.numberOfBands) {
            val hz = e.getCenterFreq(b.toShort()) / 1000
            val lbl = label(if (hz >= 1000) "${hz / 1000} kHz" else "$hz Hz")
            lbl.setPadding(0, U.dp(this, 10), 0, 0)
            box.addView(lbl)
            val sb = SeekBar(this)
            sb.max = maxL - minL
            sb.progress = e.getBandLevel(b.toShort()) - minL
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) try { e.setBandLevel(b.toShort(), (p + minL).toShort()) } catch (_: Exception) {}
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { saveEq() }
            })
            bars.add(sb)
            box.addView(sb)
        }

        if (e.numberOfPresets > 0) {
            val pb = android.widget.Button(this)
            pb.text = "Presets"
            pb.isAllCaps = false
            pb.setOnClickListener {
                val names = Array(e.numberOfPresets.toInt()) { e.getPresetName(it.toShort()) }
                AlertDialog.Builder(this).setTitle("Presets").setItems(names) { _, i ->
                    try {
                        e.usePreset(i.toShort())
                        for (b in 0 until e.numberOfBands) bars[b].progress = e.getBandLevel(b.toShort()) - minL
                        sw.isChecked = true
                        saveEq()
                    } catch (_: Exception) {}
                }.show()
            }
            box.addView(pb)
        }

        val boostLbl = label("Volume boost: ${Prefs.boost}%")
        boostLbl.setPadding(0, U.dp(this, 14), 0, 0)
        box.addView(boostLbl)
        val boost = SeekBar(this)
        boost.max = 100
        boost.progress = Prefs.boost
        boost.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                Prefs.boost = p
                boostLbl.text = "Volume boost: $p%"
                try {
                    enhancer?.setTargetGain(p * 15)
                    enhancer?.enabled = p > 0
                } catch (_: Exception) {}
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(boost)

        val sv = ScrollView(this)
        sv.addView(box)
        AlertDialog.Builder(this).setTitle("Equalizer").setView(sv).setPositiveButton("Done", null).show()
    }
}
