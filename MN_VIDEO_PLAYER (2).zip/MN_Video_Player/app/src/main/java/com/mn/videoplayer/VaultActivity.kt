package com.mn.videoplayer

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

/**
 * Private vault: videos are stored inside the app's private folder (hidden from gallery and other apps)
 * and can only be opened after entering the PIN. The screen is also blocked from screenshots and
 * hidden in the recent-apps preview.
 */
class VaultActivity : AppCompatActivity() {

    private lateinit var list: RecyclerView
    private lateinit var empty: LinearLayout
    private lateinit var info: TextView
    private lateinit var adapter: RowAdapter

    private var videos: List<Video> = emptyList()
    private var unlocked = false
    private var keepUnlocked = false
    private var asking = false
    private var loaded = false

    private val deleteLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        toast(if (r.resultCode == Activity.RESULT_OK) "Moved to the vault" else "Copied to the vault. The originals were kept.")
        reload()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContentView(R.layout.activity_vault)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.vaultRoot)) { v, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            insets
        }

        list = findViewById(R.id.vList)
        empty = findViewById(R.id.vEmpty)
        info = findViewById(R.id.vInfo)
        adapter = RowAdapter({ r, _ -> onClick(r) }, { r -> onLong(r) })
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        list.itemAnimator = null

        findViewById<ImageButton>(R.id.vBack).setOnClickListener { finish() }
        findViewById<ImageButton>(R.id.vAdd).setOnClickListener { addVideos() }
        findViewById<View>(R.id.vAddBig).setOnClickListener { addVideos() }
        findViewById<ImageButton>(R.id.vMore).setOnClickListener {
            Ui.menu(
                this, null, listOf(
                    Entry(R.drawable.ic_add, "Add videos") { addVideos() },
                    Entry(R.drawable.ic_lock, "Change PIN") { changePin() },
                    Entry(R.drawable.ic_vault, "Lock now") { finish() }
                )
            )
        }
        showLocked()
    }

    override fun onStart() {
        super.onStart()
        if (keepUnlocked) {
            keepUnlocked = false
            return
        }
        if (!unlocked) unlockFlow()
    }

    override fun onStop() {
        super.onStop()
        if (!keepUnlocked) {
            unlocked = false
            showLocked()
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ lock / unlock

    private fun showLocked() {
        list.visibility = View.GONE
        empty.visibility = View.GONE
        info.visibility = View.GONE
    }

    private fun showContent() {
        info.visibility = View.VISIBLE
        if (loaded) render()
        reload()
    }

    private fun unlockFlow() {
        if (asking) return
        asking = true
        if (Prefs.hasPin()) askPin() else createPin()
    }

    /** onOk returns true to close the dialog, false to keep it open (the field is cleared). */
    private fun pinDialog(title: String, msg: String?, onOk: (String) -> Boolean, onCancel: () -> Unit) {
        val pad = U.dp(this, 24)
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        et.filters = arrayOf(InputFilter.LengthFilter(8))
        et.hint = "PIN (4–8 digits)"
        et.gravity = Gravity.CENTER
        et.textSize = 22f
        et.setTextColor(ContextCompat.getColor(this, R.color.text))
        et.setHintTextColor(ContextCompat.getColor(this, R.color.text2))
        val box = LinearLayout(this)
        box.setPadding(pad, U.dp(this, 8), pad, 0)
        box.addView(et, LinearLayout.LayoutParams(-1, -2))
        val b = AlertDialog.Builder(this).setTitle(title).setView(box).setCancelable(false)
        if (msg != null) b.setMessage(msg)
        b.setNegativeButton("Cancel") { _, _ -> onCancel() }
        b.setPositiveButton("OK", null)
        val d = b.create()
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (onOk(et.text.toString())) d.dismiss() else et.setText("")
            }
            et.requestFocus()
            d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        }
        d.show()
    }

    private fun createPin() {
        pinDialog(
            "Create vault PIN",
            "Choose a 4–8 digit PIN. If you forget it, the videos in the vault can't be opened again.",
            { p ->
                if (p.length < 4) {
                    toast("Use at least 4 digits")
                    false
                } else {
                    confirmPin(p)
                    true
                }
            },
            { asking = false; finish() }
        )
    }

    private fun confirmPin(first: String) {
        pinDialog(
            "Confirm PIN", null,
            { p ->
                if (p == first) {
                    Prefs.setPin(p)
                    asking = false
                    unlocked = true
                    showContent()
                    true
                } else {
                    toast("The PINs don't match. Try again.")
                    createPin()
                    true
                }
            },
            { asking = false; finish() }
        )
    }

    private fun askPin() {
        val left = Prefs.vaultLockLeftMs()
        if (left > 0) {
            AlertDialog.Builder(this).setTitle("Too many wrong attempts")
                .setMessage("Please try again in ${left / 1000 + 1} seconds.")
                .setCancelable(false)
                .setPositiveButton("OK") { _, _ -> asking = false; finish() }
                .show()
            return
        }
        pinDialog(
            "Enter PIN", null,
            { p ->
                if (Prefs.checkPin(p)) {
                    asking = false
                    unlocked = true
                    showContent()
                    true
                } else if (Prefs.vaultLockLeftMs() > 0) {
                    toast("Too many wrong attempts. Try again in a moment.")
                    asking = false
                    finish()
                    true
                } else {
                    toast("Wrong PIN")
                    false
                }
            },
            { asking = false; finish() }
        )
    }

    private fun changePin() {
        pinDialog(
            "Current PIN", null,
            { p ->
                if (Prefs.checkPin(p)) {
                    newPin()
                    true
                } else {
                    toast("Wrong PIN")
                    false
                }
            },
            {}
        )
    }

    private fun newPin() {
        pinDialog(
            "New PIN", "Choose a 4–8 digit PIN.",
            { p ->
                if (p.length < 4) {
                    toast("Use at least 4 digits")
                    false
                } else {
                    pinDialog(
                        "Confirm new PIN", null,
                        { c ->
                            if (c == p) {
                                Prefs.setPin(p)
                                toast("PIN changed")
                                true
                            } else {
                                toast("The PINs don't match")
                                false
                            }
                        },
                        {}
                    )
                    true
                }
            },
            {}
        )
    }

    // ------------------------------------------------------------------ list

    private fun reload() {
        Thread {
            val v = VaultStore.list(this)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                videos = v
                loaded = true
                if (unlocked) render()
            }
        }.start()
    }

    private fun render() {
        adapter.submit(videos.map { Row.Vid(it) })
        if (!unlocked) {
            showLocked()
        } else if (videos.isEmpty()) {
            list.visibility = View.GONE
            empty.visibility = View.VISIBLE
        } else {
            empty.visibility = View.GONE
            list.visibility = View.VISIBLE
        }
    }

    private fun onClick(r: Row) {
        if (r !is Row.Vid) return
        val idx = videos.indexOfFirst { it.id == r.v.id }.coerceAtLeast(0)
        keepUnlocked = true
        PlayerActivity.start(
            this,
            ArrayList(videos.map { it.uri.toString() }),
            ArrayList(videos.map { it.name }),
            idx,
            true
        )
    }

    private fun onLong(r: Row) {
        if (r !is Row.Vid) return
        val v = r.v
        Ui.menu(
            this, v.name, listOf(
                Entry(R.drawable.ic_play, "Play") { onClick(r) },
                Entry(R.drawable.ic_unlock, "Take out of the vault", "Show it in your gallery again") { restore(v) },
                Entry(R.drawable.ic_info, "Video info") {
                    AlertDialog.Builder(this).setTitle("Video info").setMessage(
                        "Name: ${v.name}\nDuration: ${U.time(v.duration)}\nSize: ${U.size(v.size)}\n" +
                                (if (v.width > 0) "Resolution: ${v.width}×${v.height}" else "")
                    ).setPositiveButton("OK", null).show()
                },
                Entry(R.drawable.ic_delete, "Delete forever", danger = true) { confirmDelete(v) }
            )
        )
    }

    private fun restore(v: Video) {
        val prog = Ui.progress(this, "Taking the video out of the vault…")
        Thread {
            val ok = VaultStore.restore(this, File(v.uri.path ?: ""))
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                prog.dismiss()
                toast(if (ok) "Video is back in your gallery (Movies/MN Video Player)" else "Couldn't take the video out")
                reload()
            }
        }.start()
    }

    private fun confirmDelete(v: Video) {
        AlertDialog.Builder(this).setTitle("Delete forever?")
            .setMessage("${v.name}\n\nThis cannot be undone.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                val ok = File(v.uri.path ?: "").delete()
                toast(if (ok) "Video deleted" else "Couldn't delete this video")
                reload()
            }.show()
    }

    // ------------------------------------------------------------------ add videos

    private fun addVideos() {
        Thread {
            val lib = MediaRepo.load(this)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (lib.isEmpty()) {
                    toast("No videos found. Allow video access on the main screen first.")
                    return@runOnUiThread
                }
                val src = lib.sortedByDescending { it.date }
                val names = Array(src.size) { "${src[it].name}  ·  ${U.time(src[it].duration)}" }
                val checked = BooleanArray(src.size)
                AlertDialog.Builder(this).setTitle("Choose videos to hide")
                    .setMultiChoiceItems(names, checked) { _, i, on -> checked[i] = on }
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Move to vault") { _, _ ->
                        val chosen = src.filterIndexed { i, _ -> checked[i] }
                        if (chosen.isNotEmpty()) moveIn(chosen)
                    }.show()
            }
        }.start()
    }

    private fun moveIn(chosen: List<Video>) {
        val prog = Ui.progress(this, "Preparing…")
        Thread {
            val done = ArrayList<Video>()
            for ((n, v) in chosen.withIndex()) {
                runOnUiThread { Ui.setProgressText(prog, "Copying ${n + 1} of ${chosen.size}…") }
                if (VaultStore.copyIn(this, v)) done.add(v)
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                prog.dismiss()
                if (done.isEmpty()) {
                    toast("Couldn't copy the selected videos")
                    return@runOnUiThread
                }
                if (done.size < chosen.size) toast("${chosen.size - done.size} video(s) could not be copied")
                var launched = false
                val started = Ui.requestDelete(this, done.map { it.uri }) {
                    launched = true
                    keepUnlocked = true
                    deleteLauncher.launch(it)
                }
                if (!launched) {
                    toast(if (started) "Moved to the vault" else "Copied to the vault, but the originals couldn't be removed. Delete them manually.")
                    reload()
                }
            }
        }.start()
    }
}
