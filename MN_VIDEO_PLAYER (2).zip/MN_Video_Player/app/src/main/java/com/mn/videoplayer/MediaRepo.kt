package com.mn.videoplayer

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.widget.ImageView
import java.util.concurrent.Executors

object MediaRepo {
    fun load(ctx: Context): List<Video> {
        val out = ArrayList<Video>()
        val proj = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT
        )
        try {
            ctx.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj, null, null,
                MediaStore.Video.Media.DATE_ADDED + " DESC"
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val iDur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val iSize = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val iDate = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val iBucket = c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                val iW = c.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                val iH = c.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    val dur = c.getLong(iDur)
                    if (dur <= 0) continue
                    out.add(
                        Video(
                            id,
                            ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id),
                            c.getString(iName) ?: "Video $id",
                            dur,
                            c.getLong(iSize),
                            c.getLong(iDate),
                            c.getString(iBucket) ?: "Internal storage",
                            c.getInt(iW),
                            c.getInt(iH)
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return out
    }
}

object Thumbs {
    private val cache = LruCache<String, Bitmap>(120)
    private val io = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun load(ctx: Context, uri: Uri, iv: ImageView) {
        val key = uri.toString()
        iv.tag = key
        val hit = cache.get(key)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        iv.setImageDrawable(null)
        val app = ctx.applicationContext
        io.execute {
            var bmp: Bitmap? = null
            try {
                bmp = if (uri.scheme == "file") {
                    @Suppress("DEPRECATION")
                    android.media.ThumbnailUtils.createVideoThumbnail(
                        uri.path ?: "", MediaStore.Video.Thumbnails.MINI_KIND
                    )
                } else if (Build.VERSION.SDK_INT >= 29) {
                    app.contentResolver.loadThumbnail(uri, Size(360, 220), null)
                } else {
                    @Suppress("DEPRECATION")
                    MediaStore.Video.Thumbnails.getThumbnail(
                        app.contentResolver, ContentUris.parseId(uri),
                        MediaStore.Video.Thumbnails.MINI_KIND, null
                    )
                }
            } catch (_: Exception) {
            }
            if (bmp != null) {
                cache.put(key, bmp)
                main.post { if (iv.tag == key) iv.setImageBitmap(bmp) }
            }
        }
    }
}
