package com.mn.videoplayer

import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import java.io.File

/**
 * The vault keeps videos inside the app's private storage. Other apps, the gallery and file managers
 * cannot see these files. Access inside the app is protected by a PIN (see VaultActivity).
 */
object VaultStore {
    fun dir(ctx: Context): File {
        val d = File(ctx.filesDir, "vault")
        if (!d.exists()) d.mkdirs()
        return d
    }

    private fun clean(name: String): String {
        val n = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
        return if (n.isEmpty()) "video.mp4" else n
    }

    private fun uniqueFile(ctx: Context, name: String): File {
        val base = clean(name)
        var f = File(dir(ctx), base)
        var i = 1
        val stem = base.substringBeforeLast('.', base)
        val ext = if (base.contains('.')) "." + base.substringAfterLast('.') else ""
        while (f.exists()) {
            f = File(dir(ctx), "${stem}_$i$ext")
            i++
        }
        return f
    }

    /** Lists vault videos (call from a background thread, it reads file metadata). */
    fun list(ctx: Context): List<Video> {
        val files = dir(ctx).listFiles { f -> f.isFile && !f.name.startsWith(".") } ?: return emptyList()
        val out = ArrayList<Video>()
        for (f in files) {
            var dur = 0L
            var w = 0
            var h = 0
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(f.absolutePath)
                dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                w = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                h = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            } catch (_: Exception) {
            } finally {
                try { mmr.release() } catch (_: Exception) {}
            }
            out.add(
                Video(
                    f.absolutePath.hashCode().toLong(), Uri.fromFile(f), f.name, dur, f.length(),
                    f.lastModified() / 1000, "Vault", w, h
                )
            )
        }
        return out.sortedByDescending { it.date }
    }

    /** Copies a library video into the vault. The original is NOT touched here. */
    fun copyIn(ctx: Context, v: Video): Boolean {
        val target = uniqueFile(ctx, v.name)
        return try {
            val ins = ctx.contentResolver.openInputStream(v.uri) ?: return false
            ins.use { input -> target.outputStream().use { out -> input.copyTo(out, 256 * 1024) } }
            if (v.size > 0 && target.length() != v.size) {
                target.delete()
                false
            } else true
        } catch (e: Exception) {
            target.delete()
            false
        }
    }

    /** Moves a vault video back to the public Movies folder so it shows in the library again. */
    fun restore(ctx: Context, f: File): Boolean {
        return try {
            val ext = f.extension.lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "video/mp4"
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues()
                cv.put(MediaStore.Video.Media.DISPLAY_NAME, f.name)
                cv.put(MediaStore.Video.Media.MIME_TYPE, mime)
                cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MN Video Player")
                val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv) ?: return false
                val out = ctx.contentResolver.openOutputStream(uri) ?: return false
                out.use { o -> f.inputStream().use { it.copyTo(o, 256 * 1024) } }
            } else {
                val d = ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: return false
                d.mkdirs()
                f.copyTo(File(d, f.name), overwrite = false)
            }
            f.delete()
            true
        } catch (e: Exception) {
            false
        }
    }
}
