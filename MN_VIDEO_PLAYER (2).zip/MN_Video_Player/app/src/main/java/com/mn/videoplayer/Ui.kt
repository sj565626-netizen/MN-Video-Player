package com.mn.videoplayer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.IntentSenderRequest
import androidx.appcompat.app.AlertDialog

/** One line in an icon menu. */
class Entry(
    val icon: Int,
    val title: String,
    val sub: String? = null,
    val danger: Boolean = false,
    val action: () -> Unit
)

object Ui {
    private val DANGER = 0xFFF87171.toInt()

    fun header(ctx: Context, text: String): TextView {
        val t = LayoutInflater.from(ctx).inflate(R.layout.item_header, null, false) as TextView
        t.text = text
        return t
    }

    /** A row with a round icon, title and optional subtitle. Switch / value / chevron are hidden by default. */
    fun row(ctx: Context, icon: Int, title: String, sub: String?, danger: Boolean = false): View {
        val v = LayoutInflater.from(ctx).inflate(R.layout.item_setting, null, false)
        val ic = v.findViewById<ImageView>(R.id.sIcon)
        ic.setImageResource(icon)
        val t = v.findViewById<TextView>(R.id.sTitle)
        t.text = title
        val s = v.findViewById<TextView>(R.id.sSub)
        if (sub.isNullOrEmpty()) {
            s.visibility = View.GONE
        } else {
            s.text = sub
            s.visibility = View.VISIBLE
        }
        if (danger) {
            ic.setColorFilter(DANGER)
            t.setTextColor(DANGER)
        }
        return v
    }

    /** Dialog menu where every option has an icon. */
    fun menu(ctx: Context, title: String?, entries: List<Entry>) {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        val pad = U.dp(ctx, 6)
        box.setPadding(0, pad, 0, pad)
        val sv = ScrollView(ctx)
        sv.addView(box)
        val b = AlertDialog.Builder(ctx)
        if (title != null) b.setTitle(title)
        val d = b.setView(sv).create()
        for (e in entries) {
            val r = row(ctx, e.icon, e.title, e.sub, e.danger)
            r.setOnClickListener {
                d.dismiss()
                e.action()
            }
            box.addView(r)
        }
        d.show()
    }

    /** Small "please wait" dialog. Update its text later with [setProgressText]. */
    fun progress(ctx: Context, msg: String): AlertDialog {
        val v = LayoutInflater.from(ctx).inflate(R.layout.dialog_progress, null, false)
        v.findViewById<TextView>(R.id.pText).text = msg
        val d = AlertDialog.Builder(ctx).setView(v).setCancelable(false).create()
        d.show()
        return d
    }

    fun setProgressText(d: AlertDialog, msg: String) {
        d.findViewById<TextView>(R.id.pText)?.text = msg
    }

    /**
     * Asks Android to delete the original files after they were copied to the vault.
     * Returns false when the deletion could not even be started.
     */
    fun requestDelete(ctx: Context, uris: List<Uri>, launch: (IntentSenderRequest) -> Unit): Boolean {
        if (uris.isEmpty()) return true
        return try {
            if (Build.VERSION.SDK_INT >= 30) {
                val pi = MediaStore.createDeleteRequest(ctx.contentResolver, uris)
                launch(IntentSenderRequest.Builder(pi.intentSender).build())
                true
            } else {
                var n = 0
                for (u in uris) n += ctx.contentResolver.delete(u, null, null)
                n > 0
            }
        } catch (e: Exception) {
            false
        }
    }

    fun openVault(a: Activity) {
        a.startActivity(Intent(a, VaultActivity::class.java))
    }
}
