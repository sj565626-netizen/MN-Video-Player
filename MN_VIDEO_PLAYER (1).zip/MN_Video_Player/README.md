# MN Video Player

Native Android (Kotlin) video player built on Media3 ExoPlayer. English UI.

Build: upload this zip to a GitHub repo as `MN_VIDEO_PLAYER.zip` (or upload the extracted folder),
add `.github/workflows/build.yml`, run "Build MN Video Player APK" in the Actions tab, download the APK artifact.

Features: video library (grid/list, folders, search, sort), network streams (HTTP/HLS/DASH/RTSP), history and
resume, gestures (brightness, volume, seek, double-tap seek, pinch zoom, long-press 2x), speed 0.25x-4x,
audio and subtitle track selection, external subtitles (SRT/VTT/ASS/TTML) with size and color, aspect modes,
orientation control, screen lock, A-B repeat, repeat modes, sleep timer, equalizer and volume boost,
audio-only mode, background play, picture-in-picture, screenshot, video info, share, delete.
