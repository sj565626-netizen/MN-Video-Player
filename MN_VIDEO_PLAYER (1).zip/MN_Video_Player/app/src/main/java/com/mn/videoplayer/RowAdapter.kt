package com.mn.videoplayer

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.DateFormat
import java.util.Date

class RowAdapter(
    private val onClick: (Row, Int) -> Unit,
    private val onLong: (Row) -> Unit
) : RecyclerView.Adapter<RowAdapter.VH>() {

    private var rows: List<Row> = emptyList()
    var grid = false

    fun submit(r: List<Row>) {
        rows = r
        notifyDataSetChanged()
    }

    fun isHeader(pos: Int) = rows.getOrNull(pos) is Row.Header
    fun isVideo(pos: Int) = rows.getOrNull(pos) is Row.Vid

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView? = v.findViewById(R.id.thumb)
        val badge: TextView? = v.findViewById(R.id.badge)
        val prog: ProgressBar? = v.findViewById(R.id.prog)
        val title: TextView = v.findViewById(R.id.title)
        val sub: TextView? = v.findViewById(R.id.sub)
    }

    override fun getItemViewType(position: Int): Int {
        val r = rows[position]
        return when {
            r is Row.Header -> 2
            r is Row.Vid && grid -> 1
            else -> 0
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = when (viewType) {
            1 -> R.layout.item_grid
            2 -> R.layout.item_header
            else -> R.layout.item_row
        }
        return VH(LayoutInflater.from(parent.context).inflate(layout, parent, false))
    }

    override fun getItemCount() = rows.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val r = rows[position]
        val ctx = h.itemView.context
        h.prog?.visibility = View.GONE
        h.badge?.visibility = View.GONE
        h.thumb?.scaleType = ImageView.ScaleType.CENTER_CROP
        h.thumb?.clearColorFilter()
        h.thumb?.setPadding(0, 0, 0, 0)
        h.itemView.setOnClickListener { onClick(r, h.bindingAdapterPosition) }
        h.itemView.setOnLongClickListener { onLong(r); true }
        when (r) {
            is Row.Header -> {
                h.title.text = r.text
                h.itemView.setOnClickListener(null)
                h.itemView.setOnLongClickListener(null)
            }
            is Row.Vid -> {
                val v = r.v
                h.title.text = v.name
                h.sub?.text = U.time(v.duration) + " · " + U.size(v.size) +
                        (if (v.width > 0) " · ${v.width}×${v.height}" else "")
                h.badge?.text = U.time(v.duration)
                h.badge?.visibility = View.VISIBLE
                h.thumb?.let { Thumbs.load(ctx, v.uri, it) }
                val p = Prefs.getPos(v.uri.toString())
                if (p > 3000 && v.duration > 0 && p < v.duration * 0.95) {
                    h.prog?.progress = (p * 1000 / v.duration).toInt()
                    h.prog?.visibility = View.VISIBLE
                }
            }
            is Row.Folder -> {
                h.title.text = r.name
                h.sub?.text = "${r.count} videos · ${U.size(r.total)}"
                icon(h, R.drawable.ic_folder)
            }
            is Row.Action -> {
                h.title.text = r.title
                h.sub?.text = r.sub
                icon(h, r.icon)
            }
            is Row.Hist -> {
                h.title.text = r.h.title
                val d = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(r.h.time))
                h.sub?.text = d + (if (r.h.uri.startsWith("http") || r.h.uri.startsWith("rtsp")) " · Network stream" else "")
                val p = Prefs.getPos(r.h.uri)
                if (p > 3000 && r.h.duration > 0 && p < r.h.duration * 0.95) {
                    h.prog?.progress = (p * 1000 / r.h.duration).toInt()
                    h.prog?.visibility = View.VISIBLE
                }
                val local = r.h.uri.startsWith("content")
                if (local) Thumbs.load(ctx, android.net.Uri.parse(r.h.uri), h.thumb!!) else icon(h, R.drawable.ic_link)
            }
        }
    }

    private fun icon(h: VH, res: Int) {
        val t = h.thumb ?: return
        t.tag = null
        t.scaleType = ImageView.ScaleType.FIT_CENTER
        val pd = U.dp(t.context, 22)
        t.setPadding(pd, pd, pd, pd)
        t.setImageResource(res)
        t.setColorFilter(0xFF38BDF8.toInt())
    }
}
