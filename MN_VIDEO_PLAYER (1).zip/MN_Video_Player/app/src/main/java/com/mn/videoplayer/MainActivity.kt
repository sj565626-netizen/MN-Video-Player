package com.mn.videoplayer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var list: RecyclerView
    private lateinit var adapter: RowAdapter
    private lateinit var emptyView: LinearLayout
    private lateinit var emptyText: TextView
    private lateinit var btnGrant: Button
    private lateinit var searchBox: EditText
    private lateinit var resumeBar: LinearLayout
    private lateinit var resumeText: TextView
    private lateinit var btnView: ImageButton
    private lateinit var tabs: List<TextView>
    private lateinit var lm: GridLayoutManager

    private val io = Executors.newSingleThreadExecutor()
    private var videos: List<Video> = emptyList()
    private var tab = 0
    private var folder: String? = null
    private var query = ""
    private var resumeEntry: HistoryEntry? = null

    private val backCb = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            if (searchBox.visibility == View.VISIBLE) {
                closeSearch()
            } else if (folder != null) {
                folder = null
                render()
            }
        }
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) load() else showEmpty("MN Video Player needs access to your videos to show your library.", true)
    }
    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            val name = U.nameOf(this, uri)
            PlayerActivity.start(this, arrayListOf(uri.toString()), arrayListOf(name), 0)
        }
    }
    private val deleteLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            Toast.makeText(this, "Video deleted", Toast.LENGTH_SHORT).show()
        }
        load()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        setContentView(R.layout.activity_main)
        list = findViewById(R.id.list)
        emptyView = findViewById(R.id.emptyView)
        emptyText = findViewById(R.id.emptyText)
        btnGrant = findViewById(R.id.btnGrant)
        searchBox = findViewById(R.id.searchBox)
        resumeBar = findViewById(R.id.resumeBar)
        resumeText = findViewById(R.id.resumeText)
        btnView = findViewById(R.id.btnView)
        tabs = listOf(findViewById(R.id.tab0), findViewById(R.id.tab1), findViewById(R.id.tab2), findViewById(R.id.tab3))

        adapter = RowAdapter({ r, _ -> onRowClick(r) }, { r -> onRowLong(r) })
        lm = GridLayoutManager(this, 1)
        lm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (adapter.grid && !adapter.isHeader(position) && adapter.isVideo(position)) 1 else lm.spanCount
            }
        }
        list.layoutManager = lm
        list.adapter = adapter
        list.itemAnimator = null

        tabs.forEachIndexed { i, t ->
            t.setOnClickListener {
                tab = i
                folder = null
                render()
            }
        }
        findViewById<ImageButton>(R.id.btnSearch).setOnClickListener { toggleSearch() }
        findViewById<ImageButton>(R.id.btnSort).setOnClickListener { showSort() }
        btnView.setOnClickListener {
            Prefs.gridView = !Prefs.gridView
            render()
        }
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener { showSettings() }
        btnGrant.setOnClickListener { ensurePermission() }
        resumeBar.setOnClickListener { resumeEntry?.let { playEntry(it) } }
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim() ?: ""
                render()
            }
        })
        onBackPressedDispatcher.addCallback(this, backCb)
        ensurePermission()
    }

    override fun onResume() {
        super.onResume()
        if (hasPermission()) load() else render()
    }

    private fun perm() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
    else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasPermission() = ContextCompat.checkSelfPermission(this, perm()) == PackageManager.PERMISSION_GRANTED

    private fun ensurePermission() {
        if (hasPermission()) load() else permLauncher.launch(perm())
    }

    private fun load() {
        io.execute {
            val v = MediaRepo.load(this)
            runOnUiThread {
                videos = v
                render()
            }
        }
    }

    private fun showEmpty(msg: String, grant: Boolean) {
        emptyText.text = msg
        btnGrant.visibility = if (grant) View.VISIBLE else View.GONE
        emptyView.visibility = View.VISIBLE
        list.visibility = View.GONE
    }

    private fun sorted(src: List<Video>): List<Video> = when (Prefs.sortMode) {
        0 -> src.sortedBy { it.name.lowercase() }
        1 -> src.sortedByDescending { it.name.lowercase() }
        2 -> src.sortedByDescending { it.date }
        3 -> src.sortedBy { it.date }
        4 -> src.sortedByDescending { it.size }
        5 -> src.sortedBy { it.size }
        6 -> src.sortedByDescending { it.duration }
        else -> src.sortedBy { it.duration }
    }

    private fun filtered(): List<Video> {
        var src = videos
        val f = folder
        if (f != null) src = src.filter { it.folder == f }
        if (query.isNotEmpty()) src = src.filter { it.name.contains(query, ignoreCase = true) }
        return sorted(src)
    }

    private fun render() {
        tabs.forEachIndexed { i, t ->
            t.setTextColor(ContextCompat.getColor(this, if (i == tab) R.color.accent else R.color.text2))
            t.background = if (i == tab) ContextCompat.getDrawable(this, R.drawable.bg_tab_on) else null
        }
        val grid = Prefs.gridView && (tab == 0 || (tab == 1 && folder != null))
        adapter.grid = grid
        lm.spanCount = if (grid) 2 else 1
        btnView.setImageResource(if (Prefs.gridView) R.drawable.ic_list else R.drawable.ic_grid)

        val rows = ArrayList<Row>()
        var emptyMsg = "No videos found"
        when (tab) {
            0 -> {
                val v = filtered()
                v.forEach { rows.add(Row.Vid(it)) }
            }
            1 -> {
                if (folder == null) {
                    val groups = videos.filter { query.isEmpty() || it.name.contains(query, true) }.groupBy { it.folder }
                    groups.keys.sortedBy { it.lowercase() }.forEach { k ->
                        val g = groups[k]!!
                        rows.add(Row.Folder(k, g.size, g.sumOf { it.size }))
                    }
                } else {
                    filtered().forEach { rows.add(Row.Vid(it)) }
                }
            }
            2 -> {
                rows.add(Row.Action(R.drawable.ic_link, "Open network stream", "HTTP, HTTPS, HLS (m3u8), DASH, RTSP", 1))
                rows.add(Row.Action(R.drawable.ic_folder, "Browse files", "Pick a video from any folder or cloud storage", 2))
                val streams = Prefs.history().filter { it.uri.startsWith("http") || it.uri.startsWith("rtsp") }
                if (streams.isNotEmpty()) {
                    rows.add(Row.Header("RECENT STREAMS"))
                    streams.forEach { rows.add(Row.Hist(it)) }
                }
            }
            else -> {
                val h = Prefs.history()
                if (h.isNotEmpty()) {
                    rows.add(Row.Action(R.drawable.ic_delete, "Clear history", "Remove all recently played items", 3))
                    h.forEach { rows.add(Row.Hist(it)) }
                } else emptyMsg = "Nothing played yet"
            }
        }
        adapter.submit(rows)
        val needPerm = !hasPermission() && (tab == 0 || tab == 1)
        if (needPerm) {
            showEmpty("MN Video Player needs access to your videos to show your library.", true)
        } else if (rows.isEmpty()) {
            showEmpty(emptyMsg, false)
        } else {
            emptyView.visibility = View.GONE
            list.visibility = View.VISIBLE
        }
        backCb.isEnabled = folder != null || searchBox.visibility == View.VISIBLE
        updateResumeBar()
    }

    private fun updateResumeBar() {
        val h = Prefs.history().firstOrNull {
            val p = Prefs.getPos(it.uri)
            p > 5000 && it.duration > 0 && p < it.duration * 0.95
        }
        resumeEntry = h
        if (h == null) {
            resumeBar.visibility = View.GONE
        } else {
            resumeBar.visibility = View.VISIBLE
            resumeText.text = "Continue watching\n${h.title} · ${U.time(Prefs.getPos(h.uri))}"
        }
    }

    private fun onRowClick(r: Row) {
        when (r) {
            is Row.Vid -> {
                val vs = filtered()
                val idx = vs.indexOfFirst { it.id == r.v.id }.coerceAtLeast(0)
                PlayerActivity.start(
                    this,
                    ArrayList(vs.map { it.uri.toString() }),
                    ArrayList(vs.map { it.name }),
                    idx
                )
            }
            is Row.Folder -> {
                folder = r.name
                render()
            }
            is Row.Hist -> playEntry(r.h)
            is Row.Action -> when (r.id) {
                1 -> askUrl()
                2 -> pickFile.launch(arrayOf("video/*"))
                3 -> {
                    Prefs.clearHistory()
                    render()
                }
            }
            is Row.Header -> {}
        }
    }

    private fun playEntry(h: HistoryEntry) {
        PlayerActivity.start(this, arrayListOf(h.uri), arrayListOf(h.title), 0)
    }

    private fun onRowLong(r: Row) {
        if (r !is Row.Vid) return
        val v = r.v
        val items = arrayOf("Play", "Share", "Video info", "Delete")
        AlertDialog.Builder(this).setTitle(v.name).setItems(items) { _, i ->
            when (i) {
                0 -> onRowClick(r)
                1 -> {
                    val it = Intent(Intent.ACTION_SEND).apply {
                        type = "video/*"
                        putExtra(Intent.EXTRA_STREAM, v.uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(it, "Share video"))
                }
                2 -> AlertDialog.Builder(this).setTitle("Video info").setMessage(
                    "Name: ${v.name}\nFolder: ${v.folder}\nDuration: ${U.time(v.duration)}\n" +
                            "Size: ${U.size(v.size)}\nResolution: ${v.width}×${v.height}"
                ).setPositiveButton("OK", null).show()
                3 -> confirmDelete(v)
            }
        }.show()
    }

    private fun confirmDelete(v: Video) {
        AlertDialog.Builder(this).setTitle("Delete video?").setMessage(v.name)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                try {
                    if (Build.VERSION.SDK_INT >= 30) {
                        val pi = MediaStore.createDeleteRequest(contentResolver, listOf(v.uri))
                        deleteLauncher.launch(androidx.activity.result.IntentSenderRequest.Builder(pi.intentSender).build())
                    } else {
                        val n = contentResolver.delete(v.uri, null, null)
                        if (n > 0) load() else Toast.makeText(this, "Could not delete this video", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Delete is not available for this file", Toast.LENGTH_SHORT).show()
                }
            }.show()
    }

    private fun askUrl() {
        val input = EditText(this)
        input.hint = "https://example.com/video.mp4"
        input.setTextColor(ContextCompat.getColor(this, R.color.text))
        input.setHintTextColor(ContextCompat.getColor(this, R.color.text2))
        input.inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
        input.setSingleLine(true)
        val box = LinearLayout(this)
        val pad = U.dp(this, 20)
        box.setPadding(pad, U.dp(this, 8), pad, 0)
        box.addView(input, LinearLayout.LayoutParams(-1, -2))
        AlertDialog.Builder(this).setTitle("Network stream").setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Play") { _, _ ->
                val u = input.text.toString().trim()
                if (u.startsWith("http://") || u.startsWith("https://") || u.startsWith("rtsp://")) {
                    PlayerActivity.start(this, arrayListOf(u), arrayListOf(U.nameOf(this, Uri.parse(u))), 0)
                } else {
                    Toast.makeText(this, "Enter a valid http, https or rtsp link", Toast.LENGTH_SHORT).show()
                }
            }.show()
    }

    private fun toggleSearch() {
        if (searchBox.visibility == View.VISIBLE) {
            closeSearch()
        } else {
            searchBox.visibility = View.VISIBLE
            searchBox.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(searchBox, 0)
            backCb.isEnabled = true
        }
    }

    private fun closeSearch() {
        searchBox.setText("")
        searchBox.visibility = View.GONE
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(searchBox.windowToken, 0)
        query = ""
        render()
    }

    private fun showSort() {
        val items = arrayOf(
            "Name (A–Z)", "Name (Z–A)", "Newest first", "Oldest first",
            "Largest first", "Smallest first", "Longest first", "Shortest first"
        )
        AlertDialog.Builder(this).setTitle("Sort by")
            .setSingleChoiceItems(items, Prefs.sortMode) { d, i ->
                Prefs.sortMode = i
                d.dismiss()
                render()
            }.show()
    }

    private fun showSettings() {
        val steps = intArrayOf(5, 10, 15, 30)
        fun onOff(b: Boolean) = if (b) "On" else "Off"
        val items = arrayOf(
            "Resume playback: ${onOff(Prefs.resume)}",
            "Play next video automatically: ${onOff(Prefs.autoNext)}",
            "Gesture controls: ${onOff(Prefs.gestures)}",
            "Auto-rotate to video orientation: ${onOff(Prefs.autoRotate)}",
            "Play in background: ${onOff(Prefs.bgPlay)}",
            "Picture-in-picture on Home: ${onOff(Prefs.autoPip)}",
            "Double-tap seek step: ${Prefs.seekStep}s",
            "Subtitle size: ${Prefs.subSize}%",
            "About MN Video Player"
        )
        AlertDialog.Builder(this).setTitle("Settings").setItems(items) { _, i ->
            when (i) {
                0 -> Prefs.resume = !Prefs.resume
                1 -> Prefs.autoNext = !Prefs.autoNext
                2 -> Prefs.gestures = !Prefs.gestures
                3 -> Prefs.autoRotate = !Prefs.autoRotate
                4 -> Prefs.bgPlay = !Prefs.bgPlay
                5 -> Prefs.autoPip = !Prefs.autoPip
                6 -> {
                    val k = steps.indexOf(Prefs.seekStep)
                    Prefs.seekStep = steps[(k + 1) % steps.size]
                }
                7 -> {
                    val sizes = intArrayOf(70, 85, 100, 125, 150, 200)
                    val k = sizes.indexOf(Prefs.subSize)
                    Prefs.subSize = sizes[(k + 1) % sizes.size]
                }
                8 -> {
                    AlertDialog.Builder(this).setTitle("MN Video Player")
                        .setMessage("Version 1.0\nA fast, clean video player with gestures, subtitles, audio tracks, equalizer, picture-in-picture and network streaming.")
                        .setPositiveButton("OK", null).show()
                    return@setItems
                }
            }
            showSettings()
        }.setPositiveButton("Close", null).show()
    }
}
