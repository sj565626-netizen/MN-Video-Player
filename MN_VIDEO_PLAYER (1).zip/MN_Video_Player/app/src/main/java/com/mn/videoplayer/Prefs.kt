package com.mn.videoplayer

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

object Prefs {
    private var sp: SharedPreferences? = null

    fun init(c: Context) {
        if (sp == null) sp = c.applicationContext.getSharedPreferences("mnvp", Context.MODE_PRIVATE)
    }

    private fun s(): SharedPreferences = sp!!

    private fun bool(k: String, d: Boolean) = s().getBoolean(k, d)
    private fun setBool(k: String, v: Boolean) = s().edit().putBoolean(k, v).apply()

    var resume: Boolean
        get() = bool("resume", true)
        set(v) = setBool("resume", v)
    var autoNext: Boolean
        get() = bool("autoNext", true)
        set(v) = setBool("autoNext", v)
    var bgPlay: Boolean
        get() = bool("bgPlay", false)
        set(v) = setBool("bgPlay", v)
    var autoPip: Boolean
        get() = bool("autoPip", true)
        set(v) = setBool("autoPip", v)
    var autoRotate: Boolean
        get() = bool("autoRotate", true)
        set(v) = setBool("autoRotate", v)
    var gestures: Boolean
        get() = bool("gestures", true)
        set(v) = setBool("gestures", v)
    var seekStep: Int
        get() = s().getInt("seekStep", 10)
        set(v) = s().edit().putInt("seekStep", v).apply()
    var subSize: Int
        get() = s().getInt("subSize", 100)
        set(v) = s().edit().putInt("subSize", v).apply()
    var gridView: Boolean
        get() = bool("grid", false)
        set(v) = setBool("grid", v)
    var sortMode: Int
        get() = s().getInt("sort", 2)
        set(v) = s().edit().putInt("sort", v).apply()
    var eqOn: Boolean
        get() = bool("eqOn", false)
        set(v) = setBool("eqOn", v)
    var eqLevels: String
        get() = s().getString("eqLevels", "") ?: ""
        set(v) = s().edit().putString("eqLevels", v).apply()
    var subColor: Int
        get() = s().getInt("subColor", 0xFFFFFFFF.toInt())
        set(v) = s().edit().putInt("subColor", v).apply()
    var boost: Int
        get() = s().getInt("boost", 0)
        set(v) = s().edit().putInt("boost", v).apply()

    fun getPos(uri: String): Long = s().getLong("p_" + U.key(uri), 0L)
    fun setPos(uri: String, p: Long) = s().edit().putLong("p_" + U.key(uri), p).apply()

    fun history(): List<HistoryEntry> {
        val out = ArrayList<HistoryEntry>()
        try {
            val arr = JSONArray(s().getString("history", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(HistoryEntry(o.getString("u"), o.getString("t"), o.getLong("w"), o.optLong("d", 0L)))
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun addHistory(uri: String, title: String, duration: Long) {
        val list = history().filter { it.uri != uri }.toMutableList()
        list.add(0, HistoryEntry(uri, title, System.currentTimeMillis(), duration))
        while (list.size > 60) list.removeAt(list.size - 1)
        val arr = JSONArray()
        for (h in list) {
            val o = JSONObject()
            o.put("u", h.uri); o.put("t", h.title); o.put("w", h.time); o.put("d", h.duration)
            arr.put(o)
        }
        s().edit().putString("history", arr.toString()).apply()
    }

    fun clearHistory() = s().edit().putString("history", "[]").apply()
}
